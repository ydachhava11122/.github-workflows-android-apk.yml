import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

let dbInstance: Database.Database | null = null;

export function getDbPath(): string {
  const configured = process.env.DB_PATH || './data/aaknova.db';
  return path.resolve(process.cwd(), configured);
}

export function getBackupDir(): string {
  const configured = process.env.BACKUP_DIR || './data/backups';
  const resolved = path.resolve(process.cwd(), configured);
  fs.mkdirSync(resolved, { recursive: true });
  return resolved;
}

export function getDb(): Database.Database {
  if (dbInstance && dbInstance.open) {
    return dbInstance;
  }
  const dbPath = getDbPath();
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  dbInstance = new Database(dbPath);
  dbInstance.pragma('journal_mode = WAL');
  dbInstance.pragma('foreign_keys = ON');
  dbInstance.pragma('busy_timeout = 5000');
  dbInstance.pragma('synchronous = NORMAL');
  return dbInstance;
}

export function closeDb(): void {
  if (dbInstance && dbInstance.open) {
    dbInstance.pragma('wal_checkpoint(TRUNCATE)');
    dbInstance.close();
  }
  dbInstance = null;
}

export function reopenDb(): Database.Database {
  closeDb();
  return getDb();
}
