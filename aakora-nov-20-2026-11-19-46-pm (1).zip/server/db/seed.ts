import type Database from 'better-sqlite3';
import { generateStrongPassword, hashPassword } from '../security/crypto.ts';

const SYSTEM_ROLES = [
  { code: 'FOUNDER_SUPER_ADMIN', name: 'Founder Super Admin', description: 'Global sovereign control over all institutions, billing, backups, and security.', hierarchy_level: 100 },
  { code: 'INSTITUTION_ADMIN', name: 'Institution Admin', description: 'Full administrative control isolated strictly within a single institution.', hierarchy_level: 85 },
  { code: 'PRINCIPAL', name: 'Principal / Dean', description: 'Academic leadership, exams, certificates, and institutional reporting.', hierarchy_level: 75 },
  { code: 'ACCOUNTANT', name: 'Finance Officer', description: 'Fee structures, payment verification, receipts, and financial analytics.', hierarchy_level: 60 },
  { code: 'TEACHER', name: 'Faculty / Teacher', description: 'Attendance marking, grading, timetable, and student academic oversight.', hierarchy_level: 50 },
  { code: 'STAFF', name: 'Operations Staff', description: 'Library, transport, front-desk records, and facility administration.', hierarchy_level: 40 },
  { code: 'PARENT', name: 'Parent / Guardian', description: 'Read-only oversight for linked students.', hierarchy_level: 20 },
  { code: 'STUDENT', name: 'Student', description: 'Personal schedule, results, certificates, and fee statements.', hierarchy_level: 10 },
];

const SYSTEM_PERMISSIONS = [
  { code: 'institutions.manage', module: 'institutions', description: 'Create, suspend, activate, and inspect all institutions' },
  { code: 'users.manage', module: 'governance', description: 'Create, edit, suspend, and assign roles to accounts' },
  { code: 'audit.view', module: 'governance', description: 'Inspect security audit trails and login history' },
  { code: 'backups.manage', module: 'backups', description: 'Create, verify, restore database backups and download bundles' },
  { code: 'students.view', module: 'students', description: 'View student directory' },
  { code: 'students.manage', module: 'students', description: 'Create, update, and archive students' },
  { code: 'teachers.view', module: 'teachers', description: 'View faculty directory' },
  { code: 'teachers.manage', module: 'teachers', description: 'Manage faculty records and assignments' },
  { code: 'staff.view', module: 'staff', description: 'View administrative staff directory' },
  { code: 'staff.manage', module: 'staff', description: 'Manage non-teaching staff records' },
  { code: 'attendance.view', module: 'attendance', description: 'View attendance logs and metrics' },
  { code: 'attendance.mark', module: 'attendance', description: 'Mark and update daily attendance' },
  { code: 'fees.view', module: 'fees', description: 'View fee ledgers and payment history' },
  { code: 'fees.manage', module: 'fees', description: 'Manage fee structures, billing, and verified payments' },
  { code: 'exams.view', module: 'exams', description: 'View examinations and published results' },
  { code: 'exams.manage', module: 'exams', description: 'Create exams, enter marks, and publish results' },
  { code: 'timetable.view', module: 'timetable', description: 'View weekly class timetables' },
  { code: 'timetable.manage', module: 'timetable', description: 'Create, edit, and delete timetable slots' },
  { code: 'notices.view', module: 'notices', description: 'Read institutional notices and announcements' },
  { code: 'notices.manage', module: 'notices', description: 'Publish, update, and remove notices' },
  { code: 'library.view', module: 'library', description: 'Browse library catalog and active loans' },
  { code: 'library.manage', module: 'library', description: 'Manage books, issue loans, and record returns' },
  { code: 'transport.view', module: 'transport', description: 'View transport routes and assignments' },
  { code: 'transport.manage', module: 'transport', description: 'Manage fleet routes and assign students' },
  { code: 'parents.view', module: 'parents', description: 'View parent and guardian directory' },
  { code: 'parents.manage', module: 'parents', description: 'Create, edit, and link guardian accounts' },
  { code: 'certificates.view', module: 'certificates', description: 'View issued certificates' },
  { code: 'certificates.manage', module: 'certificates', description: 'Issue, print, and revoke official certificates' },
  { code: 'reports.view', module: 'reports', description: 'Access analytics dashboards and CSV/JSON exports' },
  { code: 'settings.manage', module: 'settings', description: 'Configure institution profile and settings' },
];

const ROLE_PERMISSION_MAP: Record<string, string[]> = {
  FOUNDER_SUPER_ADMIN: SYSTEM_PERMISSIONS.map((p) => p.code),
  INSTITUTION_ADMIN: SYSTEM_PERMISSIONS.filter((p) => !['institutions.manage', 'backups.manage'].includes(p.code)).map((p) => p.code),
  PRINCIPAL: [
    'audit.view', 'students.view', 'students.manage', 'teachers.view', 'teachers.manage', 'staff.view',
    'attendance.view', 'attendance.mark', 'fees.view', 'exams.view', 'exams.manage',
    'timetable.view', 'timetable.manage', 'notices.view', 'notices.manage',
    'library.view', 'transport.view', 'parents.view', 'parents.manage',
    'certificates.view', 'certificates.manage', 'reports.view',
  ],
  ACCOUNTANT: ['students.view', 'fees.view', 'fees.manage', 'transport.view', 'notices.view', 'reports.view'],
  TEACHER: [
    'students.view', 'teachers.view', 'attendance.view', 'attendance.mark',
    'exams.view', 'exams.manage', 'timetable.view', 'notices.view', 'notices.manage',
    'library.view', 'parents.view', 'certificates.view', 'reports.view',
  ],
  STAFF: [
    'students.view', 'staff.view', 'attendance.view', 'timetable.view', 'notices.view',
    'library.view', 'library.manage', 'transport.view', 'transport.manage', 'parents.view', 'certificates.view',
  ],
  PARENT: ['students.view', 'attendance.view', 'fees.view', 'exams.view', 'timetable.view', 'notices.view', 'transport.view', 'certificates.view'],
  STUDENT: ['students.view', 'attendance.view', 'fees.view', 'exams.view', 'timetable.view', 'notices.view', 'library.view', 'transport.view', 'certificates.view'],
};

/**
 * Seeds ONLY static RBAC metadata (roles & permissions).
 * NEVER hardcodes a Founder or Admin master password.
 * The Founder Super Admin account is created securely during first-run setup.
 */
export function seedSystemMetadata(db: Database.Database): void {
  const tx = db.transaction(() => {
    const insertRole = db.prepare(
      `INSERT OR IGNORE INTO roles (code, name, description, hierarchy_level, is_system) VALUES (?, ?, ?, ?, 1)`
    );
    for (const role of SYSTEM_ROLES) {
      insertRole.run(role.code, role.name, role.description, role.hierarchy_level);
    }

    const insertPerm = db.prepare(
      `INSERT OR IGNORE INTO permissions (code, module, description) VALUES (?, ?, ?)`
    );
    for (const perm of SYSTEM_PERMISSIONS) {
      insertPerm.run(perm.code, perm.module, perm.description);
    }

    const roleRows = db.prepare('SELECT id, code FROM roles').all() as { id: number; code: string }[];
    const permRows = db.prepare('SELECT id, code FROM permissions').all() as { id: number; code: string }[];
    const permMap = new Map(permRows.map((p) => [p.code, p.id]));
    const linkStmt = db.prepare(`INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)`);

    for (const role of roleRows) {
      const codes = ROLE_PERMISSION_MAP[role.code] || [];
      for (const code of codes) {
        const permId = permMap.get(code);
        if (permId) linkStmt.run(role.id, permId);
      }
    }
  });
  tx();
}

export interface ProvisionedInstitutionSummary {
  institutionId: number;
  institutionCode: string;
  institutionName: string;
  adminEmail: string;
  adminTemporaryPassword: string;
}

/**
 * Optionally populates two fully isolated multi-tenant sample institutions
 * when explicitly opted-in by the Founder during first-run setup.
 * Generates cryptographically random one-time passwords for the institution admin accounts
 * (zero hardcoded passwords) and returns them once to the Founder.
 */
export function seedSampleMultiTenantInstitutions(
  db: Database.Database,
  founderUserId: number
): ProvisionedInstitutionSummary[] {
  const existing = db.prepare('SELECT COUNT(*) as c FROM institutions').get() as { c: number };
  if (existing.c > 0) return [];

  const adminRole = db.prepare("SELECT id FROM roles WHERE code = 'INSTITUTION_ADMIN'").get() as { id: number };
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);

  const summaries: ProvisionedInstitutionSummary[] = [];

  const institutionsToCreate = [
    {
      code: 'AVN-INST-1001',
      name: 'Meridian Global Academy',
      shortName: 'MGA',
      email: 'registrar@meridian-academy.edu',
      phone: '+1 (415) 890-4100',
      address: '450 Sovereign Way, Financial District',
      city: 'San Francisco',
      plan: 'Enterprise',
      fee: 24000,
      adminName: 'Dr. Elena Vance',
      adminEmail: 'admin@meridian-academy.edu',
      adminUsername: 'elena.vance',
      courses: [
        { code: 'CS-401', name: 'Computer Science & AI Systems', dept: 'Engineering', tuition: 12800 },
        { code: 'FIN-301', name: 'Quantitative Finance & Strategy', dept: 'Business', tuition: 11400 },
      ],
      teachers: [
        { code: 'MGA-T01', name: 'Prof. Marcus Sterling', email: 'm.sterling@meridian-academy.edu', dept: 'Engineering', qual: 'PhD Computer Science', spec: 'Distributed Systems' },
        { code: 'MGA-T02', name: 'Dr. Priya Nair', email: 'p.nair@meridian-academy.edu', dept: 'Business', qual: 'PhD Econometrics', spec: 'Capital Markets' },
      ],
      students: [
        { code: 'MGA-S101', adm: 'ADM-2026-101', name: 'Aarav Mehta', email: 'aarav.m@meridian-academy.edu', guardian: 'Rajesh Mehta', gEmail: 'rajesh.mehta@example.com', gPhone: '+1 (415) 555-0141' },
        { code: 'MGA-S102', adm: 'ADM-2026-102', name: 'Sophia Laurent', email: 'sophia.l@meridian-academy.edu', guardian: 'Claire Laurent', gEmail: 'claire.laurent@example.com', gPhone: '+1 (415) 555-0142' },
        { code: 'MGA-S103', adm: 'ADM-2026-103', name: 'Daniel Okafor', email: 'daniel.o@meridian-academy.edu', guardian: 'Samuel Okafor', gEmail: 'samuel.okafor@example.com', gPhone: '+1 (415) 555-0143' },
        { code: 'MGA-S104', adm: 'ADM-2026-104', name: 'Maya Chen', email: 'maya.c@meridian-academy.edu', guardian: 'Wei Chen', gEmail: 'wei.chen@example.com', gPhone: '+1 (415) 555-0144' },
      ],
      staff: [
        { code: 'MGA-ST01', name: 'Arthur Pendelton', email: 'a.pendelton@meridian-academy.edu', dept: 'Library & Archives', desig: 'Chief Librarian', salary: 5400 },
        { code: 'MGA-ST02', name: 'Carlos Rivera', email: 'c.rivera@meridian-academy.edu', dept: 'Campus Transport', desig: 'Fleet Coordinator', salary: 4800 },
      ],
      books: [
        { isbn: '978-0-262-04630-5', title: 'Introduction to Algorithms (4th Ed.)', author: 'Cormen, Leiserson, Rivest', category: 'Computer Science', shelf: 'CS-A1', copies: 8 },
        { isbn: '978-1-119-45283-6', title: 'Options, Futures & Derivatives', author: 'John C. Hull', category: 'Finance', shelf: 'FIN-B3', copies: 5 },
      ],
      routes: [
        { code: 'MGA-R01', name: 'Marin & Golden Gate Express', vehicle: 'CA-AVN-401', driver: 'David Morales', phone: '+1 (415) 555-0191', stops: 'Sausalito -> Marina -> Campus North', capacity: 38, fee: 165 },
        { code: 'MGA-R02', name: 'East Bay Executive Shuttle', vehicle: 'CA-AVN-402', driver: 'Hannah Kim', phone: '+1 (415) 555-0192', stops: 'Oakland -> Embarcadero -> Campus South', capacity: 42, fee: 180 },
      ],
    },
    {
      code: 'AVN-INST-1002',
      name: 'Summit Horizon Institute',
      shortName: 'SHI',
      email: 'office@summit-horizon.edu',
      phone: '+1 (212) 640-7700',
      address: '820 Lexington Plaza, Midtown',
      city: 'New York',
      plan: 'Professional',
      fee: 16500,
      adminName: 'Jonathan Brooks',
      adminEmail: 'admin@summit-horizon.edu',
      adminUsername: 'jonathan.brooks',
      courses: [
        { code: 'BIO-201', name: 'Biomedical Sciences & Genetics', dept: 'Sciences', tuition: 13200 },
        { code: 'ARC-105', name: 'Sustainable Urban Architecture', dept: 'Design', tuition: 10900 },
      ],
      teachers: [
        { code: 'SHI-T01', name: 'Dr. Evelyn Park', email: 'e.park@summit-horizon.edu', dept: 'Sciences', qual: 'MD, PhD Molecular Biology', spec: 'Genomics' },
        { code: 'SHI-T02', name: 'Prof. Julian Vance', email: 'j.vance@summit-horizon.edu', dept: 'Design', qual: 'M.Arch Harvard GSD', spec: 'Structural Design' },
      ],
      students: [
        { code: 'SHI-S201', adm: 'SHI-2026-201', name: 'Liam Gallagher', email: 'liam.g@summit-horizon.edu', guardian: 'Nora Gallagher', gEmail: 'nora.g@example.com', gPhone: '+1 (212) 555-0171' },
        { code: 'SHI-S202', adm: 'SHI-2026-202', name: 'Zara Al-Mansoor', email: 'zara.a@summit-horizon.edu', guardian: 'Tariq Al-Mansoor', gEmail: 'tariq.a@example.com', gPhone: '+1 (212) 555-0172' },
        { code: 'SHI-S203', adm: 'SHI-2026-203', name: 'Noah Lindqvist', email: 'noah.l@summit-horizon.edu', guardian: 'Astrid Lindqvist', gEmail: 'astrid.l@example.com', gPhone: '+1 (212) 555-0173' },
      ],
      staff: [
        { code: 'SHI-ST01', name: 'Beatrice Holloway', email: 'b.holloway@summit-horizon.edu', dept: 'Registrar Office', desig: 'Records Officer', salary: 5100 },
      ],
      books: [
        { isbn: '978-0-815-34432-2', title: 'Molecular Biology of the Cell', author: 'Bruce Alberts', category: 'Sciences', shelf: 'BIO-C2', copies: 6 },
      ],
      routes: [
        { code: 'SHI-R01', name: 'Upper West & Central Corridor', vehicle: 'NY-AVN-801', driver: 'Omar Hassan', phone: '+1 (212) 555-0188', stops: 'Columbus Cir -> 72nd St -> Summit Campus', capacity: 36, fee: 195 },
      ],
    },
  ];

  const tx = db.transaction(() => {
    for (const inst of institutionsToCreate) {
      const instRes = db.prepare(`
        INSERT INTO institutions (institution_code, name, short_name, email, phone, address, city, subscription_plan, annual_license_fee, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
      `).run(inst.code, inst.name, inst.shortName, inst.email, inst.phone, inst.address, inst.city, inst.plan, inst.fee);
      const instId = Number(instRes.lastInsertRowid);

      const tempPassword = generateStrongPassword(14);
      db.prepare(`
        INSERT INTO users (institution_id, username, email, mobile, full_name, password_hash, role_id, status, email_verified)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'active', 1)
      `).run(instId, inst.adminUsername, inst.adminEmail, inst.phone, inst.adminName, hashPassword(tempPassword), adminRole.id);

      summaries.push({
        institutionId: instId,
        institutionCode: inst.code,
        institutionName: inst.name,
        adminEmail: inst.adminEmail,
        adminTemporaryPassword: tempPassword,
      });

      const courseIds: number[] = [];
      const classIds: number[] = [];
      const subjectIds: number[] = [];
      const teacherIds: number[] = [];

      for (const t of inst.teachers) {
        const tr = db.prepare(`
          INSERT INTO teachers (institution_id, teacher_code, full_name, email, phone, qualification, specialization, department, hire_date, performance_rating, status)
          VALUES (?, ?, ?, ?, '+1 (555) 200-3000', ?, ?, ?, '2023-08-15', 4.8, 'active')
        `).run(instId, t.code, t.name, t.email, t.qual, t.spec, t.dept);
        teacherIds.push(Number(tr.lastInsertRowid));
      }

      inst.courses.forEach((c, idx) => {
        const cr = db.prepare(`
          INSERT INTO courses (institution_id, code, name, department, duration_months, annual_tuition)
          VALUES (?, ?, ?, ?, 12, ?)
        `).run(instId, c.code, c.name, c.dept, c.tuition);
        const courseId = Number(cr.lastInsertRowid);
        courseIds.push(courseId);

        const clr = db.prepare(`
          INSERT INTO classes (institution_id, course_id, name, section, academic_year, room_number, class_teacher_id, capacity)
          VALUES (?, ?, ?, 'A', '2026-2027', ?, ?, 35)
        `).run(instId, courseId, `Cohort ${idx + 1}`, `Hall-${idx + 1}01`, teacherIds[idx] ?? null);
        classIds.push(Number(clr.lastInsertRowid));

        const sub1 = db.prepare(`
          INSERT INTO subjects (institution_id, course_id, code, name, max_marks, pass_marks, credits)
          VALUES (?, ?, ?, ?, 100, 40, 4)
        `).run(instId, courseId, `${c.code}-A`, `${c.name.split(' ')[0]} Core Foundations`);
        subjectIds.push(Number(sub1.lastInsertRowid));

        const sub2 = db.prepare(`
          INSERT INTO subjects (institution_id, course_id, code, name, max_marks, pass_marks, credits)
          VALUES (?, ?, ?, ?, 100, 40, 4)
        `).run(instId, courseId, `${c.code}-B`, `Applied ${c.dept} Seminar`);
        subjectIds.push(Number(sub2.lastInsertRowid));

        // Timetable slots
        const days = ['Monday', 'Wednesday', 'Friday'];
        days.forEach((day, dIdx) => {
          db.prepare(`
            INSERT INTO timetables (institution_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `).run(
            instId,
            classIds[idx],
            dIdx % 2 === 0 ? Number(sub1.lastInsertRowid) : Number(sub2.lastInsertRowid),
            teacherIds[idx] ?? null,
            day,
            idx === 0 ? '09:00' : '11:00',
            idx === 0 ? '10:30' : '12:30',
            `Hall-${idx + 1}01`
          );
        });

        // Fee structure
        db.prepare(`
          INSERT INTO fee_structures (institution_id, course_id, title, category, amount, due_day, frequency, academic_year)
          VALUES (?, ?, ?, 'Tuition', ?, 15, 'semester', '2026-2027')
        `).run(instId, courseId, `${c.code} Semester Tuition`, Math.round(c.tuition / 2));
      });

      const studentIds: number[] = [];
      inst.students.forEach((s, idx) => {
        const cIdx = idx % courseIds.length;
        const sr = db.prepare(`
          INSERT INTO students (
            institution_id, student_code, admission_number, full_name, email, phone,
            date_of_birth, gender, course_id, class_id, guardian_name, guardian_phone, guardian_email, admission_date, status
          ) VALUES (?, ?, ?, ?, ?, '+1 (555) 310-0000', '2004-05-14', 'Unspecified', ?, ?, ?, ?, ?, '2026-08-20', 'active')
        `).run(instId, s.code, s.adm, s.name, s.email, courseIds[cIdx], classIds[cIdx], s.guardian, s.gPhone, s.gEmail);
        const sid = Number(sr.lastInsertRowid);
        studentIds.push(sid);

        // Parent record & link
        const pr = db.prepare(`
          INSERT INTO parents (institution_id, full_name, email, phone, occupation, address)
          VALUES (?, ?, ?, ?, 'Executive', ?)
        `).run(instId, s.guardian, s.gEmail, s.gPhone, inst.city);
        db.prepare(`INSERT INTO parent_students (parent_id, student_id, relationship) VALUES (?, ?, 'Parent')`).run(Number(pr.lastInsertRowid), sid);

        // Attendance (today & yesterday)
        db.prepare(`
          INSERT INTO attendance (institution_id, entity_type, student_id, class_id, attendance_date, status, marked_by)
          VALUES (?, 'student', ?, ?, ?, ?, ?)
        `).run(instId, sid, classIds[cIdx], today, idx === 2 ? 'late' : 'present', founderUserId);
        db.prepare(`
          INSERT INTO attendance (institution_id, entity_type, student_id, class_id, attendance_date, status, marked_by)
          VALUES (?, 'student', ?, ?, ?, 'present', ?)
        `).run(instId, sid, classIds[cIdx], yesterday, founderUserId);

        // Fee ledger & verified payment
        const gross = Math.round(inst.courses[cIdx].tuition / 2);
        const paid = idx % 2 === 0 ? gross : Math.round(gross * 0.5);
        const status = paid >= gross ? 'paid' : 'partial';
        const fr = db.prepare(`
          INSERT INTO fees (institution_id, student_id, title, academic_year, gross_amount, discount_amount, net_amount, paid_amount, due_date, status)
          VALUES (?, ?, 'Fall 2026 Semester Tuition', '2026-2027', ?, 0, ?, ?, '2026-10-15', ?)
        `).run(instId, sid, gross, gross, paid, status);

        if (paid > 0) {
          db.prepare(`
            INSERT INTO payments (institution_id, fee_id, student_id, receipt_number, amount, payment_method, verification_source, transaction_reference, verified_by, verified_at, status)
            VALUES (?, ?, ?, ?, ?, 'bank_transfer', 'authorized_manual', ?, ?, datetime('now'), 'verified')
          `).run(instId, Number(fr.lastInsertRowid), sid, `RCPT-${inst.shortName}-${202600 + idx}`, paid, `TXN-${inst.shortName}-${9000 + idx}`, founderUserId);
        }
      });

      // Teacher attendance
      teacherIds.forEach((tid) => {
        db.prepare(`
          INSERT INTO attendance (institution_id, entity_type, teacher_id, attendance_date, status, marked_by)
          VALUES (?, 'teacher', ?, ?, 'present', ?)
        `).run(instId, tid, today, founderUserId);
      });

      // Staff
      for (const st of inst.staff) {
        db.prepare(`
          INSERT INTO staff (institution_id, staff_code, full_name, email, phone, department, designation, hire_date, monthly_salary, status)
          VALUES (?, ?, ?, ?, '+1 (555) 440-1000', ?, ?, '2024-02-01', ?, 'active')
        `).run(instId, st.code, st.name, st.email, st.dept, st.desig, st.salary);
      }

      // Examination & Results
      const exRes = db.prepare(`
        INSERT INTO examinations (institution_id, name, exam_type, course_id, class_id, academic_year, start_date, end_date, status, published_at, created_by)
        VALUES (?, 'Autumn Midterm Assessment 2026', 'Midterm', ?, ?, '2026-2027', '2026-10-10', '2026-10-18', 'published', datetime('now'), ?)
      `).run(instId, courseIds[0], classIds[0], founderUserId);
      const examId = Number(exRes.lastInsertRowid);

      studentIds.filter((_, idx) => idx % courseIds.length === 0).forEach((sid, idx) => {
        const marks = 84 + idx * 5;
        db.prepare(`
          INSERT INTO results (institution_id, examination_id, student_id, subject_id, marks_obtained, max_marks, percentage, grade, remarks, entered_by)
          VALUES (?, ?, ?, ?, ?, 100, ?, ?, 'Commendable analytical rigor', ?)
        `).run(instId, examId, sid, subjectIds[0], marks, marks, marks >= 90 ? 'A+' : 'A', founderUserId);
      });

      // Library books & one active issue
      const bookIds: number[] = [];
      for (const b of inst.books) {
        const br = db.prepare(`
          INSERT INTO library_books (institution_id, isbn, title, author, category, shelf_location, total_copies, available_copies, status)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available')
        `).run(instId, b.isbn, b.title, b.author, b.category, b.shelf, b.copies, b.copies - 1);
        bookIds.push(Number(br.lastInsertRowid));
      }
      if (bookIds[0] && studentIds[0]) {
        db.prepare(`
          INSERT INTO library_issues (institution_id, book_id, student_id, issued_date, due_date, status, issued_by)
          VALUES (?, ?, ?, ?, '2026-12-05', 'issued', ?)
        `).run(instId, bookIds[0], studentIds[0], today, founderUserId);
      }

      // Transport routes & assignment
      const routeIds: number[] = [];
      for (const r of inst.routes) {
        const rr = db.prepare(`
          INSERT INTO transport_routes (institution_id, route_code, route_name, vehicle_number, driver_name, driver_phone, stops, capacity, monthly_fee, status)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
        `).run(instId, r.code, r.name, r.vehicle, r.driver, r.phone, r.stops, r.capacity, r.fee);
        routeIds.push(Number(rr.lastInsertRowid));
      }
      if (routeIds[0] && studentIds[0]) {
        db.prepare(`
          INSERT INTO transport_assignments (institution_id, route_id, student_id, pickup_stop, status)
          VALUES (?, ?, ?, 'Main Hub Terminal', 'active')
        `).run(instId, routeIds[0], studentIds[0]);
      }

      // Official Certificate
      if (studentIds[0]) {
        db.prepare(`
          INSERT INTO certificates (institution_id, certificate_number, student_id, certificate_type, issue_date, remarks, signed_by, status, created_by)
          VALUES (?, ?, ?, 'Bonafide', ?, 'Active full-time enrollment verified in good academic standing.', ?, 'issued', ?)
        `).run(instId, `AVN-CERT-${inst.shortName}-2026-001`, studentIds[0], today, inst.adminName, founderUserId);
      }

      // Notice
      db.prepare(`
        INSERT INTO notices (institution_id, title, content, category, priority, target_roles, published_by)
        VALUES (?, ?, ?, 'announcement', 'high', 'ALL', ?)
      `).run(
        instId,
        `${inst.name} — Academic Term Governance Update`,
        'All faculty rosters, examination timetables, library allocations, and tuition ledgers are synchronized for the 2026-2027 academic session.',
        founderUserId
      );
    }
  });
  tx();

  return summaries;
}
