import type Database from 'better-sqlite3';

interface Migration {
  version: number;
  name: string;
  sql: string;
}

const migrations: Migration[] = [
  {
    version: 1,
    name: '001_aaknova_multitenant_enterprise_schema',
    sql: `
      CREATE TABLE IF NOT EXISTS institutions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        short_name TEXT NOT NULL DEFAULT '',
        email TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        city TEXT NOT NULL DEFAULT '',
        country TEXT NOT NULL DEFAULT 'United States',
        website TEXT NOT NULL DEFAULT '',
        academic_year TEXT NOT NULL DEFAULT '2026-2027',
        currency_symbol TEXT NOT NULL DEFAULT '$',
        subscription_plan TEXT NOT NULL DEFAULT 'Enterprise' CHECK (subscription_plan IN ('Standard','Professional','Enterprise')),
        annual_license_fee REAL NOT NULL DEFAULT 18000 CHECK (annual_license_fee >= 0),
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        hierarchy_level INTEGER NOT NULL DEFAULT 10,
        is_system INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS permissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        module TEXT NOT NULL,
        description TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS role_permissions (
        role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
        permission_id INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
        PRIMARY KEY (role_id, permission_id)
      );

      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER REFERENCES institutions(id) ON DELETE CASCADE,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        mobile TEXT NOT NULL DEFAULT '',
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role_id INTEGER NOT NULL REFERENCES roles(id),
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','suspended','archived')),
        avatar_url TEXT,
        email_verified INTEGER NOT NULL DEFAULT 1,
        failed_login_attempts INTEGER NOT NULL DEFAULT 0,
        locked_until TEXT,
        language TEXT NOT NULL DEFAULT 'en',
        theme TEXT NOT NULL DEFAULT 'dark' CHECK (theme IN ('light','dark','system')),
        notify_email INTEGER NOT NULL DEFAULT 1,
        notify_push INTEGER NOT NULL DEFAULT 1,
        last_login_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token_hash TEXT NOT NULL UNIQUE,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        csrf_token TEXT NOT NULL,
        remember_me INTEGER NOT NULL DEFAULT 0,
        ip_address TEXT NOT NULL DEFAULT '',
        user_agent TEXT NOT NULL DEFAULT '',
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS login_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        institution_id INTEGER REFERENCES institutions(id) ON DELETE SET NULL,
        identifier TEXT NOT NULL,
        outcome TEXT NOT NULL CHECK (outcome IN ('success','failed','locked','suspended')),
        ip_address TEXT NOT NULL DEFAULT '',
        user_agent TEXT NOT NULL DEFAULT '',
        reason TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token_hash TEXT NOT NULL UNIQUE,
        expires_at TEXT NOT NULL,
        used_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        department TEXT NOT NULL,
        duration_months INTEGER NOT NULL DEFAULT 12,
        annual_tuition REAL NOT NULL DEFAULT 0 CHECK (annual_tuition >= 0),
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, code)
      );

      CREATE TABLE IF NOT EXISTS teachers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE SET NULL,
        teacher_code TEXT NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        qualification TEXT NOT NULL DEFAULT '',
        specialization TEXT NOT NULL DEFAULT '',
        department TEXT NOT NULL DEFAULT 'General',
        hire_date TEXT NOT NULL,
        work_schedule TEXT NOT NULL DEFAULT 'Mon-Fri, 08:30-16:00',
        performance_rating REAL NOT NULL DEFAULT 4.5 CHECK (performance_rating >= 0 AND performance_rating <= 5),
        performance_notes TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','on_leave','archived')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, teacher_code),
        UNIQUE(institution_id, email)
      );

      CREATE TABLE IF NOT EXISTS classes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        section TEXT NOT NULL DEFAULT 'A',
        academic_year TEXT NOT NULL,
        room_number TEXT NOT NULL DEFAULT '',
        class_teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
        capacity INTEGER NOT NULL DEFAULT 40,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, course_id, name, section, academic_year)
      );

      CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        max_marks REAL NOT NULL DEFAULT 100 CHECK (max_marks > 0),
        pass_marks REAL NOT NULL DEFAULT 40 CHECK (pass_marks >= 0),
        credits INTEGER NOT NULL DEFAULT 4,
        UNIQUE(institution_id, code)
      );

      CREATE TABLE IF NOT EXISTS teacher_assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
        class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        academic_year TEXT NOT NULL,
        UNIQUE(teacher_id, class_id, subject_id, academic_year)
      );

      CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE SET NULL,
        student_code TEXT NOT NULL,
        admission_number TEXT NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        date_of_birth TEXT NOT NULL DEFAULT '',
        gender TEXT NOT NULL DEFAULT 'Unspecified',
        address TEXT NOT NULL DEFAULT '',
        photo_url TEXT,
        course_id INTEGER NOT NULL REFERENCES courses(id),
        class_id INTEGER NOT NULL REFERENCES classes(id),
        guardian_name TEXT NOT NULL DEFAULT '',
        guardian_phone TEXT NOT NULL DEFAULT '',
        guardian_email TEXT NOT NULL DEFAULT '',
        admission_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','graduated','suspended','archived')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, student_code),
        UNIQUE(institution_id, admission_number)
      );

      CREATE TABLE IF NOT EXISTS parents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE SET NULL,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        occupation TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, email)
      );

      CREATE TABLE IF NOT EXISTS parent_students (
        parent_id INTEGER NOT NULL REFERENCES parents(id) ON DELETE CASCADE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        relationship TEXT NOT NULL DEFAULT 'Guardian',
        PRIMARY KEY (parent_id, student_id)
      );

      CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE SET NULL,
        staff_code TEXT NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        department TEXT NOT NULL,
        designation TEXT NOT NULL,
        hire_date TEXT NOT NULL,
        shift_schedule TEXT NOT NULL DEFAULT 'Mon-Fri, 08:00-17:00',
        monthly_salary REAL NOT NULL DEFAULT 0 CHECK (monthly_salary >= 0),
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','on_leave','archived')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, staff_code),
        UNIQUE(institution_id, email)
      );

      CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        entity_type TEXT NOT NULL CHECK (entity_type IN ('student','teacher')),
        student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
        teacher_id INTEGER REFERENCES teachers(id) ON DELETE CASCADE,
        class_id INTEGER REFERENCES classes(id) ON DELETE SET NULL,
        attendance_date TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('present','absent','late')),
        remarks TEXT NOT NULL DEFAULT '',
        marked_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        CHECK (
          (entity_type = 'student' AND student_id IS NOT NULL AND teacher_id IS NULL) OR
          (entity_type = 'teacher' AND teacher_id IS NOT NULL AND student_id IS NULL)
        )
      );

      CREATE TABLE IF NOT EXISTS fee_structures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Tuition',
        amount REAL NOT NULL CHECK (amount >= 0),
        due_day INTEGER NOT NULL DEFAULT 15,
        frequency TEXT NOT NULL DEFAULT 'semester' CHECK (frequency IN ('monthly','quarterly','semester','annual','one_time')),
        academic_year TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS fees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        fee_structure_id INTEGER REFERENCES fee_structures(id) ON DELETE SET NULL,
        title TEXT NOT NULL,
        academic_year TEXT NOT NULL,
        gross_amount REAL NOT NULL CHECK (gross_amount >= 0),
        discount_amount REAL NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
        net_amount REAL NOT NULL CHECK (net_amount >= 0),
        paid_amount REAL NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
        due_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','partial','paid','overdue','waived')),
        concession_reason TEXT NOT NULL DEFAULT '',
        reminder_sent_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        fee_id INTEGER NOT NULL REFERENCES fees(id) ON DELETE CASCADE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        receipt_number TEXT NOT NULL UNIQUE,
        amount REAL NOT NULL CHECK (amount > 0),
        payment_method TEXT NOT NULL CHECK (payment_method IN ('bank_transfer','card_gateway','upi_verified','cheque','cash_counter')),
        verification_source TEXT NOT NULL CHECK (verification_source IN ('payment_gateway','authorized_manual')),
        transaction_reference TEXT NOT NULL,
        verified_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        verified_at TEXT,
        status TEXT NOT NULL DEFAULT 'pending_verification' CHECK (status IN ('pending_verification','verified','rejected','refunded')),
        notes TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS examinations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        exam_type TEXT NOT NULL DEFAULT 'Midterm',
        course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
        class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
        academic_year TEXT NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('draft','scheduled','published')),
        published_at TEXT,
        created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        examination_id INTEGER NOT NULL REFERENCES examinations(id) ON DELETE CASCADE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        marks_obtained REAL NOT NULL CHECK (marks_obtained >= 0),
        max_marks REAL NOT NULL CHECK (max_marks > 0),
        percentage REAL NOT NULL,
        grade TEXT NOT NULL,
        remarks TEXT NOT NULL DEFAULT '',
        entered_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(examination_id, student_id, subject_id)
      );

      CREATE TABLE IF NOT EXISTS timetables (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
        day_of_week TEXT NOT NULL CHECK (day_of_week IN ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')),
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        room_number TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER REFERENCES institutions(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'notice' CHECK (category IN ('notice','announcement','alert')),
        priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high','urgent')),
        target_roles TEXT NOT NULL DEFAULT 'ALL',
        published_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        expires_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER REFERENCES institutions(id) ON DELETE CASCADE,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        notice_id INTEGER REFERENCES notices(id) ON DELETE SET NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'notice',
        is_read INTEGER NOT NULL DEFAULT 0,
        read_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS library_books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        isbn TEXT NOT NULL,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Academic',
        shelf_location TEXT NOT NULL DEFAULT 'A-01',
        total_copies INTEGER NOT NULL DEFAULT 1 CHECK (total_copies >= 0),
        available_copies INTEGER NOT NULL DEFAULT 1 CHECK (available_copies >= 0),
        status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','checked_out','archived')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, isbn)
      );

      CREATE TABLE IF NOT EXISTS library_issues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        book_id INTEGER NOT NULL REFERENCES library_books(id) ON DELETE CASCADE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        issued_date TEXT NOT NULL,
        due_date TEXT NOT NULL,
        returned_date TEXT,
        fine_amount REAL NOT NULL DEFAULT 0 CHECK (fine_amount >= 0),
        status TEXT NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','returned','overdue')),
        issued_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS transport_routes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        route_code TEXT NOT NULL,
        route_name TEXT NOT NULL,
        vehicle_number TEXT NOT NULL,
        driver_name TEXT NOT NULL,
        driver_phone TEXT NOT NULL DEFAULT '',
        stops TEXT NOT NULL DEFAULT '',
        capacity INTEGER NOT NULL DEFAULT 40 CHECK (capacity > 0),
        monthly_fee REAL NOT NULL DEFAULT 120 CHECK (monthly_fee >= 0),
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','maintenance','inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, route_code)
      );

      CREATE TABLE IF NOT EXISTS transport_assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        route_id INTEGER NOT NULL REFERENCES transport_routes(id) ON DELETE CASCADE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        pickup_stop TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(institution_id, student_id)
      );

      CREATE TABLE IF NOT EXISTS certificates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        certificate_number TEXT NOT NULL UNIQUE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        certificate_type TEXT NOT NULL CHECK (certificate_type IN ('Bonafide','Transfer','Character','Course Completion','Merit Award')),
        issue_date TEXT NOT NULL,
        remarks TEXT NOT NULL DEFAULT '',
        signed_by TEXT NOT NULL DEFAULT 'Principal / Registrar',
        status TEXT NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','revoked')),
        created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        document_type TEXT NOT NULL DEFAULT 'Admission Record',
        file_name TEXT NOT NULL,
        mime_type TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        content_base64 TEXT NOT NULL,
        uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        institution_id INTEGER REFERENCES institutions(id) ON DELETE SET NULL,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        actor_name TEXT NOT NULL,
        actor_role TEXT NOT NULL,
        action TEXT NOT NULL,
        resource_type TEXT NOT NULL,
        resource_id TEXT NOT NULL DEFAULT '',
        details TEXT NOT NULL DEFAULT '',
        ip_address TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL UNIQUE,
        file_path TEXT NOT NULL,
        size_bytes INTEGER NOT NULL,
        sha256_hash TEXT NOT NULL,
        table_summary TEXT NOT NULL DEFAULT '{}',
        status TEXT NOT NULL DEFAULT 'verified' CHECK (status IN ('verified','corrupted','restored')),
        created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        restored_at TEXT
      );

      CREATE TABLE IF NOT EXISTS institution_settings (
        institution_id INTEGER NOT NULL DEFAULT 0,
        key TEXT NOT NULL,
        value TEXT NOT NULL,
        updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        PRIMARY KEY (institution_id, key)
      );

      CREATE UNIQUE INDEX IF NOT EXISTS idx_attendance_student_date
        ON attendance(institution_id, student_id, attendance_date)
        WHERE student_id IS NOT NULL;

      CREATE UNIQUE INDEX IF NOT EXISTS idx_attendance_teacher_date
        ON attendance(institution_id, teacher_id, attendance_date)
        WHERE teacher_id IS NOT NULL;

      CREATE INDEX IF NOT EXISTS idx_users_inst ON users(institution_id);
      CREATE INDEX IF NOT EXISTS idx_students_inst ON students(institution_id);
      CREATE INDEX IF NOT EXISTS idx_teachers_inst ON teachers(institution_id);
      CREATE INDEX IF NOT EXISTS idx_staff_inst ON staff(institution_id);
      CREATE INDEX IF NOT EXISTS idx_attendance_inst_date ON attendance(institution_id, attendance_date);
      CREATE INDEX IF NOT EXISTS idx_fees_inst ON fees(institution_id, status);
      CREATE INDEX IF NOT EXISTS idx_payments_inst ON payments(institution_id);
      CREATE INDEX IF NOT EXISTS idx_exams_inst ON examinations(institution_id);
      CREATE INDEX IF NOT EXISTS idx_results_inst ON results(institution_id);
      CREATE INDEX IF NOT EXISTS idx_timetables_inst ON timetables(institution_id);
      CREATE INDEX IF NOT EXISTS idx_library_inst ON library_books(institution_id);
      CREATE INDEX IF NOT EXISTS idx_transport_inst ON transport_routes(institution_id);
      CREATE INDEX IF NOT EXISTS idx_certificates_inst ON certificates(institution_id);
      CREATE INDEX IF NOT EXISTS idx_audit_inst ON audit_logs(institution_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_login_hist_created ON login_history(created_at DESC);
    `,
  },
];

export function runMigrations(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const applied = new Set<number>(
    (db.prepare('SELECT version FROM schema_migrations').all() as { version: number }[]).map((r) => r.version)
  );

  for (const m of migrations) {
    if (!applied.has(m.version)) {
      const tx = db.transaction(() => {
        db.exec(m.sql);
        db.prepare('INSERT INTO schema_migrations (version, name) VALUES (?, ?)').run(m.version, m.name);
      });
      tx();
    }
  }
}
