import { execFileSync } from 'child_process';
import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import { getBackupDir, getDb, getDbPath, reopenDb } from '../db/connection.ts';
import { sha256 } from '../security/crypto.ts';
import { recordAudit, requireAuth, requireCsrf, requireFounder } from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);

function getTableCounts() {
  const db = getDb();
  const tables = [
    'institutions', 'users', 'students', 'teachers', 'staff', 'parents',
    'attendance', 'fees', 'payments', 'examinations', 'results',
    'timetables', 'notices', 'library_books', 'transport_routes', 'certificates',
  ];
  const counts: Record<string, number> = {};
  for (const tbl of tables) {
    try {
      counts[tbl] = (db.prepare(`SELECT COUNT(*) as c FROM ${tbl}`).get() as { c: number }).c;
    } catch {
      counts[tbl] = 0;
    }
  }
  return counts;
}

router.get('/', requireFounder, (_req, res) => {
  const db = getDb();
  const backups = db.prepare('SELECT * FROM backups ORDER BY created_at DESC').all();
  res.json({ backups, currentCounts: getTableCounts() });
});

router.post('/create', requireFounder, async (req, res) => {
  const db = getDb();
  const backupDir = getBackupDir();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `aaknova-backup-${stamp}.db`;
  const targetPath = path.join(backupDir, filename);

  try {
    await db.backup(targetPath);
    const buffer = fs.readFileSync(targetPath);
    const hash = sha256(buffer);
    const summary = JSON.stringify(getTableCounts());

    const r = db
      .prepare(
        `INSERT INTO backups (filename, file_path, size_bytes, sha256_hash, table_summary, status, created_by)
         VALUES (?, ?, ?, ?, ?, 'verified', ?)`
      )
      .run(filename, targetPath, buffer.length, hash, summary, req.user!.id);

    recordAudit(req, 'BACKUP_CREATED', 'backup', Number(r.lastInsertRowid), `Created verified snapshot ${filename} (${buffer.length} bytes)`);
    res.status(201).json({
      backup: db.prepare('SELECT * FROM backups WHERE id = ?').get(r.lastInsertRowid),
      message: `Verified database backup ${filename} created.`,
    });
  } catch (err) {
    console.error('Backup creation failed:', err);
    res.status(500).json({ error: 'Failed to create database backup snapshot.' });
  }
});

router.post('/:id/verify', requireFounder, (req, res) => {
  const id = Number(req.params.id);
  const db = getDb();
  const row = db.prepare('SELECT * FROM backups WHERE id = ?').get(id) as
    | { id: number; filename: string; file_path: string; sha256_hash: string }
    | undefined;
  if (!row) {
    res.status(404).json({ error: 'Backup record not found.' });
    return;
  }
  if (!fs.existsSync(row.file_path)) {
    db.prepare(`UPDATE backups SET status = 'corrupted' WHERE id = ?`).run(id);
    res.status(400).json({ verified: false, error: 'Backup file is missing from storage.' });
    return;
  }
  const actualHash = sha256(fs.readFileSync(row.file_path));
  const verified = actualHash === row.sha256_hash;
  db.prepare(`UPDATE backups SET status = ? WHERE id = ?`).run(verified ? 'verified' : 'corrupted', id);
  recordAudit(req, 'BACKUP_VERIFIED', 'backup', id, `Integrity check ${verified ? 'PASSED' : 'FAILED'} for ${row.filename}`);
  res.json({ verified, expectedHash: row.sha256_hash, actualHash });
});

router.post('/:id/restore', requireFounder, (req, res) => {
  const id = Number(req.params.id);
  const db = getDb();
  const row = db.prepare('SELECT * FROM backups WHERE id = ?').get(id) as
    | { id: number; filename: string; file_path: string; sha256_hash: string }
    | undefined;
  if (!row || !fs.existsSync(row.file_path)) {
    res.status(404).json({ error: 'Backup snapshot file not found.' });
    return;
  }

  const actualHash = sha256(fs.readFileSync(row.file_path));
  if (actualHash !== row.sha256_hash) {
    res.status(400).json({ error: 'Backup integrity verification failed (SHA-256 mismatch). Restore aborted.' });
    return;
  }

  try {
    const dbPath = getDbPath();
    // Preserve current active session token so the Founder stays signed in after restore
    const currentSessions = db.prepare('SELECT * FROM sessions').all() as Record<string, unknown>[];
    const currentBackupRows = db.prepare('SELECT * FROM backups').all() as Record<string, unknown>[];

    // Close DB, remove WAL/SHM sidecars, copy snapshot cleanly, reopen
    db.pragma('wal_checkpoint(TRUNCATE)');
    db.close();
    for (const suffix of ['-wal', '-shm']) {
      if (fs.existsSync(`${dbPath}${suffix}`)) {
        fs.unlinkSync(`${dbPath}${suffix}`);
      }
    }
    fs.copyFileSync(row.file_path, dbPath);

    const freshDb = reopenDb();
    // Ensure backup history and current Founder session remain intact after restore
    for (const b of currentBackupRows) {
      freshDb
        .prepare(
          `INSERT OR IGNORE INTO backups (filename, file_path, size_bytes, sha256_hash, table_summary, status, created_by, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(b.filename, b.file_path, b.size_bytes, b.sha256_hash, b.table_summary, b.status, b.created_by, b.created_at);
    }
    freshDb.prepare(`UPDATE backups SET status = 'restored', restored_at = datetime('now') WHERE filename = ?`).run(row.filename);
    for (const s of currentSessions) {
      const userExists = freshDb.prepare('SELECT id FROM users WHERE id = ?').get(s.user_id);
      if (userExists) {
        freshDb
          .prepare(
            `INSERT OR IGNORE INTO sessions (token_hash, user_id, csrf_token, remember_me, ip_address, user_agent, expires_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)`
          )
          .run(s.token_hash, s.user_id, s.csrf_token, s.remember_me, s.ip_address, s.user_agent, s.expires_at);
      }
    }

    recordAudit(req, 'BACKUP_RESTORED', 'backup', id, `Restored database from ${row.filename}`);
    res.json({ message: `Database restored cleanly from ${row.filename}.`, counts: getTableCounts() });
  } catch (err) {
    console.error('Restore failed:', err);
    reopenDb();
    res.status(500).json({ error: 'Database restore failed. Original connection reopened.' });
  }
});

router.get('/:id/download', requireFounder, (req, res) => {
  const id = Number(req.params.id);
  const row = getDb().prepare('SELECT filename, file_path FROM backups WHERE id = ?').get(id) as
    | { filename: string; file_path: string }
    | undefined;
  if (!row || !fs.existsSync(row.file_path)) {
    res.status(404).json({ error: 'Backup file not found.' });
    return;
  }
  res.download(row.file_path, row.filename);
});

router.get('/export-json', requireFounder, (_req, res) => {
  const db = getDb();
  const payload = {
    exportedAt: new Date().toISOString(),
    platform: 'AAKNOVA',
    institutions: db.prepare('SELECT * FROM institutions').all(),
    students: db.prepare('SELECT * FROM students').all(),
    teachers: db.prepare('SELECT * FROM teachers').all(),
    staff: db.prepare('SELECT * FROM staff').all(),
    fees: db.prepare('SELECT * FROM fees').all(),
    payments: db.prepare('SELECT * FROM payments').all(),
    examinations: db.prepare('SELECT * FROM examinations').all(),
    results: db.prepare('SELECT * FROM results').all(),
    certificates: db.prepare('SELECT * FROM certificates').all(),
  };
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename="aaknova-enterprise-report-${new Date().toISOString().slice(0, 10)}.json"`);
  res.send(JSON.stringify(payload, null, 2));
});

/**
 * Generates a REAL, verified downloadable ZIP archive of the complete AAKNOVA source tree
 * (React frontend, Express server, Python Flask/SQLAlchemy/PostgreSQL backend, Capacitor Android project, & docs).
 */
router.get('/project-zip', requireFounder, (req, res) => {
  try {
    const outDir = path.resolve(process.cwd(), 'data', 'deliverables');
    fs.mkdirSync(outDir, { recursive: true });
    const zipPath = path.join(outDir, 'aaknova-complete-enterprise-project.zip');

    const pyScript = `
import os, zipfile, sys
root = os.getcwd()
out_zip = sys.argv[1]
skip_dirs = {'node_modules', 'dist', '.git', 'data', '__pycache__', '.venv'}
with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        for fname in filenames:
            if fname.endswith(('.db', '.db-wal', '.db-shm', '.zip')):
                continue
            full = os.path.join(dirpath, fname)
            rel = os.path.relpath(full, root)
            zf.write(full, os.path.join('aaknova', rel))
`;
    execFileSync('python3', ['-c', pyScript, zipPath], { cwd: process.cwd(), timeout: 20000 });
    recordAudit(req, 'PROJECT_ZIP_EXPORTED', 'deliverable', 'zip', 'Generated and downloaded complete AAKNOVA project ZIP');
    res.download(zipPath, 'aaknova-complete-enterprise-project.zip');
  } catch (err) {
    console.error('Project ZIP generation error:', err);
    res.status(500).json({ error: 'Unable to package project ZIP archive.' });
  }
});

export default router;
