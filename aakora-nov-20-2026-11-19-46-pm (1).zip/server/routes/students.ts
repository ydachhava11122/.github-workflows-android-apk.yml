import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  requireTenantScope,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);
router.use(requireTenantScope);

router.get('/', requirePermission('students.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;
  const q = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
  const status = typeof req.query.status === 'string' ? req.query.status : '';
  const classId = req.query.classId ? Number(req.query.classId) : null;

  let sql = `
    SELECT s.*, c.name as course_name, c.code as course_code, cl.name as class_name, cl.section as class_section
    FROM students s
    JOIN courses c ON c.id = s.course_id
    JOIN classes cl ON cl.id = s.class_id
    WHERE s.institution_id = ?
  `;
  const params: unknown[] = [tid];

  if (req.user!.roleCode === 'STUDENT' && req.user!.studentId) {
    sql += ' AND s.id = ?';
    params.push(req.user!.studentId);
  } else if (req.user!.roleCode === 'PARENT') {
    if (req.user!.linkedStudentIds.length === 0) {
      res.json({ students: [] });
      return;
    }
    sql += ` AND s.id IN (${req.user!.linkedStudentIds.map(() => '?').join(',')})`;
    params.push(...req.user!.linkedStudentIds);
  }

  if (status && status !== 'all') {
    sql += ' AND s.status = ?';
    params.push(status);
  }
  if (classId && Number.isFinite(classId)) {
    sql += ' AND s.class_id = ?';
    params.push(classId);
  }
  if (q) {
    sql += ' AND (lower(s.full_name) LIKE ? OR lower(s.student_code) LIKE ? OR lower(s.admission_number) LIKE ? OR lower(s.email) LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }

  sql += ' ORDER BY s.id DESC';
  const students = db.prepare(sql).all(...params);
  res.json({ students });
});

const studentSchema = z.object({
  fullName: z.string().min(2).max(120),
  email: z.string().email().max(160),
  phone: z.string().max(30).optional().default(''),
  dateOfBirth: z.string().max(20).optional().default(''),
  gender: z.string().max(24).optional().default('Unspecified'),
  address: z.string().max(240).optional().default(''),
  courseId: z.coerce.number().int().positive(),
  classId: z.coerce.number().int().positive(),
  guardianName: z.string().max(120).optional().default(''),
  guardianPhone: z.string().max(30).optional().default(''),
  guardianEmail: z.string().max(160).optional().default(''),
  admissionDate: z.string().max(20).optional(),
  status: z.enum(['active', 'graduated', 'suspended', 'archived']).optional().default('active'),
});

router.post('/', requirePermission('students.manage'), (req, res) => {
  const parsed = studentSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid student record.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;

  // Verify course & class belong to the SAME institution tenant
  const course = db.prepare('SELECT id FROM courses WHERE id = ? AND institution_id = ?').get(d.courseId, tid);
  const cls = db.prepare('SELECT id FROM classes WHERE id = ? AND institution_id = ?').get(d.classId, tid);
  if (!course || !cls) {
    res.status(400).json({ error: 'Selected course or class does not belong to this institution.' });
    return;
  }

  const count = (db.prepare('SELECT COUNT(*) as c FROM students WHERE institution_id = ?').get(tid) as { c: number }).c;
  const studentCode = `STU-${tid}-${String(101 + count + Math.floor(Math.random() * 50))}`;
  const admissionNumber = `ADM-${new Date().getFullYear()}-${tid}${String(1000 + count + Math.floor(Math.random() * 90))}`;

  const result = db
    .prepare(
      `INSERT INTO students (
        institution_id, student_code, admission_number, full_name, email, phone, date_of_birth, gender, address,
        course_id, class_id, guardian_name, guardian_phone, guardian_email, admission_date, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      tid,
      studentCode,
      admissionNumber,
      sanitizeText(d.fullName, 120),
      d.email.trim().toLowerCase(),
      sanitizeText(d.phone, 30),
      sanitizeText(d.dateOfBirth, 20),
      sanitizeText(d.gender, 24),
      sanitizeText(d.address, 240),
      d.courseId,
      d.classId,
      sanitizeText(d.guardianName, 120),
      sanitizeText(d.guardianPhone, 30),
      sanitizeText(d.guardianEmail, 160),
      d.admissionDate || new Date().toISOString().slice(0, 10),
      d.status
    );

  const id = Number(result.lastInsertRowid);
  recordAudit(req, 'STUDENT_CREATED', 'student', id, `Enrolled ${d.fullName} (${studentCode})`);
  const created = db
    .prepare(
      `SELECT s.*, c.name as course_name, c.code as course_code, cl.name as class_name, cl.section as class_section
       FROM students s JOIN courses c ON c.id = s.course_id JOIN classes cl ON cl.id = s.class_id
       WHERE s.id = ? AND s.institution_id = ?`
    )
    .get(id, tid);
  res.status(201).json({ student: created });
});

router.put('/:id', requirePermission('students.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const existing = db.prepare('SELECT * FROM students WHERE id = ? AND institution_id = ?').get(id, tid);
  if (!existing) {
    res.status(404).json({ error: 'Student not found in this institution.' });
    return;
  }

  const parsed = studentSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid student update payload.' });
    return;
  }
  const d = parsed.data;
  const course = db.prepare('SELECT id FROM courses WHERE id = ? AND institution_id = ?').get(d.courseId, tid);
  const cls = db.prepare('SELECT id FROM classes WHERE id = ? AND institution_id = ?').get(d.classId, tid);
  if (!course || !cls) {
    res.status(400).json({ error: 'Course or class does not belong to this institution.' });
    return;
  }

  db.prepare(
    `UPDATE students
     SET full_name = ?, email = ?, phone = ?, date_of_birth = ?, gender = ?, address = ?,
         course_id = ?, class_id = ?, guardian_name = ?, guardian_phone = ?, guardian_email = ?, status = ?, updated_at = datetime('now')
     WHERE id = ? AND institution_id = ?`
  ).run(
    sanitizeText(d.fullName, 120),
    d.email.trim().toLowerCase(),
    sanitizeText(d.phone, 30),
    sanitizeText(d.dateOfBirth, 20),
    sanitizeText(d.gender, 24),
    sanitizeText(d.address, 240),
    d.courseId,
    d.classId,
    sanitizeText(d.guardianName, 120),
    sanitizeText(d.guardianPhone, 30),
    sanitizeText(d.guardianEmail, 160),
    d.status,
    id,
    tid
  );

  recordAudit(req, 'STUDENT_UPDATED', 'student', id, `Updated student ${d.fullName}`);
  const updated = db
    .prepare(
      `SELECT s.*, c.name as course_name, c.code as course_code, cl.name as class_name, cl.section as class_section
       FROM students s JOIN courses c ON c.id = s.course_id JOIN classes cl ON cl.id = s.class_id
       WHERE s.id = ? AND s.institution_id = ?`
    )
    .get(id, tid);
  res.json({ student: updated });
});

router.delete('/:id', requirePermission('students.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const existing = db.prepare('SELECT full_name FROM students WHERE id = ? AND institution_id = ?').get(id, tid) as
    | { full_name: string }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Student not found in this institution.' });
    return;
  }
  db.prepare('DELETE FROM students WHERE id = ? AND institution_id = ?').run(id, tid);
  recordAudit(req, 'STUDENT_DELETED', 'student', id, `Removed student ${existing.full_name}`);
  res.json({ message: `Student ${existing.full_name} deleted.` });
});

export default router;
