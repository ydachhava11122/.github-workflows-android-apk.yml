import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import { recordAudit, requireAuth, requireCsrf, requireTenantScope, sanitizeText } from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);
router.use(requireTenantScope);

router.get('/catalog', (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;

  const courses = db
    .prepare(
      `SELECT c.*,
        (SELECT COUNT(*) FROM students s WHERE s.course_id = c.id AND s.institution_id = c.institution_id AND s.status != 'archived') as student_count,
        (SELECT COUNT(*) FROM classes cl WHERE cl.course_id = c.id AND cl.institution_id = c.institution_id) as class_count
       FROM courses c WHERE c.institution_id = ? ORDER BY c.id ASC`
    )
    .all(tid);

  const classes = db
    .prepare(
      `SELECT cl.*, c.name as course_name, c.code as course_code, t.full_name as teacher_name,
        (SELECT COUNT(*) FROM students s WHERE s.class_id = cl.id AND s.institution_id = cl.institution_id AND s.status != 'archived') as student_count
       FROM classes cl
       JOIN courses c ON c.id = cl.course_id
       LEFT JOIN teachers t ON t.id = cl.class_teacher_id
       WHERE cl.institution_id = ?
       ORDER BY cl.id ASC`
    )
    .all(tid);

  const subjects = db
    .prepare(
      `SELECT sub.*, c.name as course_name, c.code as course_code
       FROM subjects sub
       JOIN courses c ON c.id = sub.course_id
       WHERE sub.institution_id = ?
       ORDER BY sub.id ASC`
    )
    .all(tid);

  res.json({ courses, classes, subjects });
});

router.post('/courses', (req, res) => {
  const schema = z.object({
    code: z.string().min(2).max(24),
    name: z.string().min(2).max(120),
    department: z.string().min(2).max(80),
    durationMonths: z.coerce.number().int().min(1).max(120).optional().default(12),
    annualTuition: z.coerce.number().min(0).optional().default(0),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid course input.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  try {
    const r = db
      .prepare(
        `INSERT INTO courses (institution_id, code, name, department, duration_months, annual_tuition)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(tid, sanitizeText(d.code, 24).toUpperCase(), sanitizeText(d.name, 120), sanitizeText(d.department, 80), d.durationMonths, d.annualTuition);
    recordAudit(req, 'COURSE_CREATED', 'course', Number(r.lastInsertRowid), `Created course ${d.code}`);
    res.status(201).json({ course: db.prepare('SELECT * FROM courses WHERE id = ?').get(r.lastInsertRowid) });
  } catch {
    res.status(409).json({ error: 'A course with that code already exists in this institution.' });
  }
});

router.post('/classes', (req, res) => {
  const schema = z.object({
    courseId: z.coerce.number().int().positive(),
    name: z.string().min(1).max(60),
    section: z.string().min(1).max(10).optional().default('A'),
    academicYear: z.string().min(4).max(24).optional().default('2026-2027'),
    roomNumber: z.string().max(40).optional().default(''),
    capacity: z.coerce.number().int().min(5).max(300).optional().default(40),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid class input.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const course = db.prepare('SELECT id FROM courses WHERE id = ? AND institution_id = ?').get(d.courseId, tid);
  if (!course) {
    res.status(400).json({ error: 'Selected course does not belong to this institution.' });
    return;
  }
  try {
    const r = db
      .prepare(
        `INSERT INTO classes (institution_id, course_id, name, section, academic_year, room_number, capacity)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(tid, d.courseId, sanitizeText(d.name, 60), sanitizeText(d.section, 10), sanitizeText(d.academicYear, 24), sanitizeText(d.roomNumber, 40), d.capacity);
    recordAudit(req, 'CLASS_CREATED', 'class', Number(r.lastInsertRowid), `Created class ${d.name}-${d.section}`);
    res.status(201).json({ class: db.prepare('SELECT * FROM classes WHERE id = ?').get(r.lastInsertRowid) });
  } catch {
    res.status(409).json({ error: 'That class/section already exists for this course and year.' });
  }
});

router.post('/subjects', (req, res) => {
  const schema = z.object({
    courseId: z.coerce.number().int().positive(),
    code: z.string().min(2).max(24),
    name: z.string().min(2).max(120),
    maxMarks: z.coerce.number().min(10).max(500).optional().default(100),
    passMarks: z.coerce.number().min(0).max(500).optional().default(40),
    credits: z.coerce.number().int().min(1).max(20).optional().default(4),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid subject input.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const course = db.prepare('SELECT id FROM courses WHERE id = ? AND institution_id = ?').get(d.courseId, tid);
  if (!course) {
    res.status(400).json({ error: 'Course does not belong to this institution.' });
    return;
  }
  try {
    const r = db
      .prepare(
        `INSERT INTO subjects (institution_id, course_id, code, name, max_marks, pass_marks, credits)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(tid, d.courseId, sanitizeText(d.code, 24).toUpperCase(), sanitizeText(d.name, 120), d.maxMarks, d.passMarks, d.credits);
    res.status(201).json({ subject: db.prepare('SELECT * FROM subjects WHERE id = ?').get(r.lastInsertRowid) });
  } catch {
    res.status(409).json({ error: 'Subject code already exists in this institution.' });
  }
});

export default router;
