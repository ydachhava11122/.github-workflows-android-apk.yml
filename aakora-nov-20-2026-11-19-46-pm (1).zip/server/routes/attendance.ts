import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  requireTenantScope,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);
router.use(requireTenantScope);

router.get('/', requirePermission('attendance.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;
  const date = typeof req.query.date === 'string' && req.query.date ? req.query.date : new Date().toISOString().slice(0, 10);
  const entityType = req.query.entityType === 'teacher' ? 'teacher' : 'student';
  const classId = req.query.classId ? Number(req.query.classId) : null;

  if (entityType === 'student') {
    let sql = `
      SELECT s.id as entity_id, s.student_code as code, s.full_name, cl.name as class_name, cl.section as class_section,
             a.id as attendance_id, COALESCE(a.status, 'unmarked') as status, COALESCE(a.remarks, '') as remarks
      FROM students s
      JOIN classes cl ON cl.id = s.class_id
      LEFT JOIN attendance a
        ON a.student_id = s.id AND a.institution_id = s.institution_id AND a.attendance_date = ? AND a.entity_type = 'student'
      WHERE s.institution_id = ? AND s.status = 'active'
    `;
    const params: unknown[] = [date, tid];
    if (classId && Number.isFinite(classId)) {
      sql += ' AND s.class_id = ?';
      params.push(classId);
    }
    sql += ' ORDER BY s.full_name ASC';
    const roster = db.prepare(sql).all(...params);
    res.json({ date, entityType, roster });
    return;
  }

  const roster = db
    .prepare(
      `SELECT t.id as entity_id, t.teacher_code as code, t.full_name, t.department as class_name, '' as class_section,
              a.id as attendance_id, COALESCE(a.status, 'unmarked') as status, COALESCE(a.remarks, '') as remarks
       FROM teachers t
       LEFT JOIN attendance a
         ON a.teacher_id = t.id AND a.institution_id = t.institution_id AND a.attendance_date = ? AND a.entity_type = 'teacher'
       WHERE t.institution_id = ? AND t.status = 'active'
       ORDER BY t.full_name ASC`
    )
    .all(date, tid);

  res.json({ date, entityType, roster });
});

const bulkMarkSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  entityType: z.enum(['student', 'teacher']),
  records: z.array(
    z.object({
      entityId: z.coerce.number().int().positive(),
      status: z.enum(['present', 'absent', 'late']),
      remarks: z.string().max(200).optional().default(''),
    })
  ).min(1),
});

router.post('/mark', requirePermission('attendance.mark'), (req, res) => {
  const parsed = bulkMarkSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid attendance payload.' });
    return;
  }

  const db = getDb();
  const tid = req.tenantId!;
  const { date, entityType, records } = parsed.data;

  const tx = db.transaction(() => {
    for (const rec of records) {
      if (entityType === 'student') {
        const student = db.prepare('SELECT id, class_id FROM students WHERE id = ? AND institution_id = ?').get(rec.entityId, tid) as
          | { id: number; class_id: number }
          | undefined;
        if (!student) continue;

        const existing = db
          .prepare("SELECT id FROM attendance WHERE institution_id = ? AND student_id = ? AND attendance_date = ? AND entity_type = 'student'")
          .get(tid, student.id, date) as { id: number } | undefined;

        if (existing) {
          db.prepare(`UPDATE attendance SET status = ?, remarks = ?, marked_by = ?, updated_at = datetime('now') WHERE id = ?`).run(
            rec.status,
            sanitizeText(rec.remarks, 200),
            req.user!.id,
            existing.id
          );
        } else {
          db.prepare(
            `INSERT INTO attendance (institution_id, entity_type, student_id, class_id, attendance_date, status, remarks, marked_by)
             VALUES (?, 'student', ?, ?, ?, ?, ?, ?)`
          ).run(tid, student.id, student.class_id, date, rec.status, sanitizeText(rec.remarks, 200), req.user!.id);
        }
      } else {
        const teacher = db.prepare('SELECT id FROM teachers WHERE id = ? AND institution_id = ?').get(rec.entityId, tid) as
          | { id: number }
          | undefined;
        if (!teacher) continue;

        const existing = db
          .prepare("SELECT id FROM attendance WHERE institution_id = ? AND teacher_id = ? AND attendance_date = ? AND entity_type = 'teacher'")
          .get(tid, teacher.id, date) as { id: number } | undefined;

        if (existing) {
          db.prepare(`UPDATE attendance SET status = ?, remarks = ?, marked_by = ?, updated_at = datetime('now') WHERE id = ?`).run(
            rec.status,
            sanitizeText(rec.remarks, 200),
            req.user!.id,
            existing.id
          );
        } else {
          db.prepare(
            `INSERT INTO attendance (institution_id, entity_type, teacher_id, attendance_date, status, remarks, marked_by)
             VALUES (?, 'teacher', ?, ?, ?, ?, ?)`
          ).run(tid, teacher.id, date, rec.status, sanitizeText(rec.remarks, 200), req.user!.id);
        }
      }
    }
  });
  tx();

  recordAudit(req, 'ATTENDANCE_MARKED', 'attendance', date, `Saved ${records.length} ${entityType} attendance records for ${date}`);
  res.json({ message: `Saved ${records.length} ${entityType} attendance entries for ${date}.` });
});

router.delete('/:id', requirePermission('attendance.mark'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const r = db.prepare('DELETE FROM attendance WHERE id = ? AND institution_id = ?').run(id, tid);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Attendance record not found in this institution.' });
    return;
  }
  recordAudit(req, 'ATTENDANCE_DELETED', 'attendance', id, 'Removed attendance record');
  res.json({ message: 'Attendance record deleted.' });
});

export default router;
