import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  requireTenantScope,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);
router.use(requireTenantScope);

/* ============================================================================
 * 1. STAFF MANAGEMENT
 * ========================================================================== */
router.get('/staff', requirePermission('staff.view'), (req, res) => {
  const db = getDb();
  const staff = db.prepare('SELECT * FROM staff WHERE institution_id = ? ORDER BY id DESC').all(req.tenantId!);
  res.json({ staff });
});

router.post('/staff', requirePermission('staff.manage'), (req, res) => {
  const schema = z.object({
    fullName: z.string().min(2).max(120),
    email: z.string().email().max(160),
    phone: z.string().max(30).optional().default(''),
    department: z.string().min(2).max(80),
    designation: z.string().min(2).max(80),
    hireDate: z.string().max(20).optional(),
    shiftSchedule: z.string().max(80).optional().default('Mon-Fri, 08:00-17:00'),
    monthlySalary: z.coerce.number().min(0).optional().default(4000),
    status: z.enum(['active', 'on_leave', 'archived']).optional().default('active'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid staff input.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const count = (db.prepare('SELECT COUNT(*) as c FROM staff WHERE institution_id = ?').get(tid) as { c: number }).c;
  const code = `STF-${tid}-${100 + count + Math.floor(Math.random() * 50)}`;
  try {
    const r = db
      .prepare(
        `INSERT INTO staff (institution_id, staff_code, full_name, email, phone, department, designation, hire_date, shift_schedule, monthly_salary, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        tid,
        code,
        sanitizeText(d.fullName, 120),
        d.email.trim().toLowerCase(),
        sanitizeText(d.phone, 30),
        sanitizeText(d.department, 80),
        sanitizeText(d.designation, 80),
        d.hireDate || new Date().toISOString().slice(0, 10),
        sanitizeText(d.shiftSchedule, 80),
        d.monthlySalary,
        d.status
      );
    recordAudit(req, 'STAFF_CREATED', 'staff', Number(r.lastInsertRowid), `Added staff ${d.fullName}`);
    res.status(201).json({ staff: db.prepare('SELECT * FROM staff WHERE id = ?').get(r.lastInsertRowid) });
  } catch {
    res.status(409).json({ error: 'A staff member with this email already exists in this institution.' });
  }
});

router.put('/staff/:id', requirePermission('staff.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const existing = db.prepare('SELECT id FROM staff WHERE id = ? AND institution_id = ?').get(id, tid);
  if (!existing) {
    res.status(404).json({ error: 'Staff record not found in this institution.' });
    return;
  }
  const d = req.body;
  db.prepare(
    `UPDATE staff SET full_name = ?, email = ?, phone = ?, department = ?, designation = ?, shift_schedule = ?, monthly_salary = ?, status = ?
     WHERE id = ? AND institution_id = ?`
  ).run(
    sanitizeText(d.fullName, 120),
    String(d.email || '').trim().toLowerCase(),
    sanitizeText(d.phone, 30),
    sanitizeText(d.department, 80),
    sanitizeText(d.designation, 80),
    sanitizeText(d.shiftSchedule, 80),
    Math.max(0, Number(d.monthlySalary || 0)),
    ['active', 'on_leave', 'archived'].includes(d.status) ? d.status : 'active',
    id,
    tid
  );
  recordAudit(req, 'STAFF_UPDATED', 'staff', id, `Updated staff ${d.fullName}`);
  res.json({ staff: db.prepare('SELECT * FROM staff WHERE id = ?').get(id) });
});

router.delete('/staff/:id', requirePermission('staff.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM staff WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Staff record not found.' });
    return;
  }
  recordAudit(req, 'STAFF_DELETED', 'staff', id, 'Removed staff record');
  res.json({ message: 'Staff member deleted.' });
});

/* ============================================================================
 * 2. TIMETABLE MANAGEMENT
 * ========================================================================== */
router.get('/timetables', requirePermission('timetable.view'), (req, res) => {
  const db = getDb();
  const slots = db
    .prepare(
      `SELECT tt.*, cl.name as class_name, cl.section as class_section, sub.name as subject_name, sub.code as subject_code, t.full_name as teacher_name
       FROM timetables tt
       JOIN classes cl ON cl.id = tt.class_id
       JOIN subjects sub ON sub.id = tt.subject_id
       LEFT JOIN teachers t ON t.id = tt.teacher_id
       WHERE tt.institution_id = ?
       ORDER BY
         CASE tt.day_of_week
           WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
           WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 ELSE 6
         END, tt.start_time ASC`
    )
    .all(req.tenantId!);
  res.json({ slots });
});

router.post('/timetables', requirePermission('timetable.manage'), (req, res) => {
  const schema = z.object({
    classId: z.coerce.number().int().positive(),
    subjectId: z.coerce.number().int().positive(),
    teacherId: z.coerce.number().int().positive().nullable().optional(),
    dayOfWeek: z.enum(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']),
    startTime: z.string().min(4).max(10),
    endTime: z.string().min(4).max(10),
    roomNumber: z.string().max(40).optional().default(''),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid timetable slot.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const cls = db.prepare('SELECT id FROM classes WHERE id = ? AND institution_id = ?').get(d.classId, tid);
  const sub = db.prepare('SELECT id FROM subjects WHERE id = ? AND institution_id = ?').get(d.subjectId, tid);
  if (!cls || !sub) {
    res.status(400).json({ error: 'Class or subject does not belong to this institution.' });
    return;
  }
  const r = db
    .prepare(
      `INSERT INTO timetables (institution_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(tid, d.classId, d.subjectId, d.teacherId || null, d.dayOfWeek, sanitizeText(d.startTime, 10), sanitizeText(d.endTime, 10), sanitizeText(d.roomNumber, 40));
  recordAudit(req, 'TIMETABLE_SLOT_CREATED', 'timetable', Number(r.lastInsertRowid), `Scheduled ${d.dayOfWeek} ${d.startTime}-${d.endTime}`);
  res.status(201).json({ slot: db.prepare('SELECT * FROM timetables WHERE id = ?').get(r.lastInsertRowid) });
});

router.delete('/timetables/:id', requirePermission('timetable.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM timetables WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Timetable slot not found.' });
    return;
  }
  recordAudit(req, 'TIMETABLE_SLOT_DELETED', 'timetable', id, 'Deleted timetable slot');
  res.json({ message: 'Timetable slot deleted.' });
});

/* ============================================================================
 * 3. LIBRARY MANAGEMENT (BOOKS + ISSUE/RETURN)
 * ========================================================================== */
router.get('/library', requirePermission('library.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;
  const books = db.prepare('SELECT * FROM library_books WHERE institution_id = ? ORDER BY id DESC').all(tid);
  const issues = db
    .prepare(
      `SELECT li.*, b.title as book_title, b.isbn, s.full_name as student_name, s.student_code
       FROM library_issues li
       JOIN library_books b ON b.id = li.book_id
       JOIN students s ON s.id = li.student_id
       WHERE li.institution_id = ?
       ORDER BY li.id DESC`
    )
    .all(tid);
  res.json({ books, issues });
});

router.post('/library/books', requirePermission('library.manage'), (req, res) => {
  const schema = z.object({
    isbn: z.string().min(3).max(40),
    title: z.string().min(2).max(180),
    author: z.string().min(2).max(120),
    category: z.string().max(60).optional().default('Academic'),
    shelfLocation: z.string().max(30).optional().default('A-01'),
    totalCopies: z.coerce.number().int().min(1).max(500).default(1),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid book input.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  try {
    const r = db
      .prepare(
        `INSERT INTO library_books (institution_id, isbn, title, author, category, shelf_location, total_copies, available_copies, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available')`
      )
      .run(tid, sanitizeText(d.isbn, 40), sanitizeText(d.title, 180), sanitizeText(d.author, 120), sanitizeText(d.category, 60), sanitizeText(d.shelfLocation, 30), d.totalCopies, d.totalCopies);
    recordAudit(req, 'BOOK_ADDED', 'library_book', Number(r.lastInsertRowid), `Cataloged "${d.title}"`);
    res.status(201).json({ book: db.prepare('SELECT * FROM library_books WHERE id = ?').get(r.lastInsertRowid) });
  } catch {
    res.status(409).json({ error: 'A book with this ISBN already exists in this institution.' });
  }
});

router.delete('/library/books/:id', requirePermission('library.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM library_books WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Book not found.' });
    return;
  }
  recordAudit(req, 'BOOK_DELETED', 'library_book', id, 'Removed book from catalog');
  res.json({ message: 'Book removed from library.' });
});

router.post('/library/issues', requirePermission('library.manage'), (req, res) => {
  const schema = z.object({
    bookId: z.coerce.number().int().positive(),
    studentId: z.coerce.number().int().positive(),
    dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid book issue request.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const book = db.prepare('SELECT * FROM library_books WHERE id = ? AND institution_id = ?').get(d.bookId, tid) as
    | { id: number; available_copies: number; title: string }
    | undefined;
  const student = db.prepare('SELECT id FROM students WHERE id = ? AND institution_id = ?').get(d.studentId, tid);
  if (!book || !student) {
    res.status(404).json({ error: 'Book or student not found in this institution.' });
    return;
  }
  if (book.available_copies <= 0) {
    res.status(400).json({ error: 'No available copies left for this title.' });
    return;
  }
  let issueId = 0;
  const tx = db.transaction(() => {
    const r = db
      .prepare(
        `INSERT INTO library_issues (institution_id, book_id, student_id, issued_date, due_date, status, issued_by)
         VALUES (?, ?, ?, ?, ?, 'issued', ?)`
      )
      .run(tid, book.id, d.studentId, new Date().toISOString().slice(0, 10), d.dueDate, req.user!.id);
    issueId = Number(r.lastInsertRowid);
    const remaining = book.available_copies - 1;
    db.prepare(`UPDATE library_books SET available_copies = ?, status = ? WHERE id = ?`).run(
      remaining,
      remaining === 0 ? 'checked_out' : 'available',
      book.id
    );
  });
  tx();
  recordAudit(req, 'BOOK_ISSUED', 'library_issue', issueId, `Issued "${book.title}"`);
  res.status(201).json({ issue: db.prepare('SELECT * FROM library_issues WHERE id = ?').get(issueId) });
});

router.patch('/library/issues/:id/return', requirePermission('library.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const issue = db.prepare('SELECT * FROM library_issues WHERE id = ? AND institution_id = ?').get(id, tid) as
    | { id: number; book_id: number; status: string }
    | undefined;
  if (!issue || issue.status === 'returned') {
    res.status(404).json({ error: 'Active library loan not found.' });
    return;
  }
  const fineAmount = Math.max(0, Number(req.body?.fineAmount || 0));
  const tx = db.transaction(() => {
    db.prepare(`UPDATE library_issues SET status = 'returned', returned_date = ?, fine_amount = ? WHERE id = ?`).run(
      new Date().toISOString().slice(0, 10),
      fineAmount,
      issue.id
    );
    db.prepare(`UPDATE library_books SET available_copies = available_copies + 1, status = 'available' WHERE id = ?`).run(issue.book_id);
  });
  tx();
  recordAudit(req, 'BOOK_RETURNED', 'library_issue', id, `Returned book loan (fine: ${fineAmount})`);
  res.json({ message: 'Book return recorded successfully.' });
});

/* ============================================================================
 * 4. TRANSPORT MANAGEMENT (ROUTES + ASSIGNMENTS)
 * ========================================================================== */
router.get('/transport', requirePermission('transport.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;
  const routes = db
    .prepare(
      `SELECT tr.*, (SELECT COUNT(*) FROM transport_assignments ta WHERE ta.route_id = tr.id AND ta.status = 'active') as assigned_count
       FROM transport_routes tr WHERE tr.institution_id = ? ORDER BY tr.id DESC`
    )
    .all(tid);
  const assignments = db
    .prepare(
      `SELECT ta.*, tr.route_code, tr.route_name, tr.vehicle_number, s.full_name as student_name, s.student_code
       FROM transport_assignments ta
       JOIN transport_routes tr ON tr.id = ta.route_id
       JOIN students s ON s.id = ta.student_id
       WHERE ta.institution_id = ? ORDER BY ta.id DESC`
    )
    .all(tid);
  res.json({ routes, assignments });
});

router.post('/transport/routes', requirePermission('transport.manage'), (req, res) => {
  const schema = z.object({
    routeCode: z.string().min(2).max(24),
    routeName: z.string().min(2).max(120),
    vehicleNumber: z.string().min(2).max(40),
    driverName: z.string().min(2).max(100),
    driverPhone: z.string().max(30).optional().default(''),
    stops: z.string().max(240).optional().default(''),
    capacity: z.coerce.number().int().min(5).max(120).optional().default(40),
    monthlyFee: z.coerce.number().min(0).optional().default(150),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid transport route.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  try {
    const r = db
      .prepare(
        `INSERT INTO transport_routes (institution_id, route_code, route_name, vehicle_number, driver_name, driver_phone, stops, capacity, monthly_fee, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`
      )
      .run(tid, sanitizeText(d.routeCode, 24).toUpperCase(), sanitizeText(d.routeName, 120), sanitizeText(d.vehicleNumber, 40), sanitizeText(d.driverName, 100), sanitizeText(d.driverPhone, 30), sanitizeText(d.stops, 240), d.capacity, d.monthlyFee);
    recordAudit(req, 'TRANSPORT_ROUTE_CREATED', 'transport_route', Number(r.lastInsertRowid), `Created route ${d.routeName}`);
    res.status(201).json({ route: db.prepare('SELECT * FROM transport_routes WHERE id = ?').get(r.lastInsertRowid) });
  } catch {
    res.status(409).json({ error: 'Route code already exists in this institution.' });
  }
});

router.delete('/transport/routes/:id', requirePermission('transport.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM transport_routes WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Route not found.' });
    return;
  }
  recordAudit(req, 'TRANSPORT_ROUTE_DELETED', 'transport_route', id, 'Deleted transport route');
  res.json({ message: 'Transport route deleted.' });
});

router.post('/transport/assignments', requirePermission('transport.manage'), (req, res) => {
  const schema = z.object({
    routeId: z.coerce.number().int().positive(),
    studentId: z.coerce.number().int().positive(),
    pickupStop: z.string().min(2).max(120),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid transport assignment.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const route = db.prepare('SELECT id FROM transport_routes WHERE id = ? AND institution_id = ?').get(d.routeId, tid);
  const student = db.prepare('SELECT id FROM students WHERE id = ? AND institution_id = ?').get(d.studentId, tid);
  if (!route || !student) {
    res.status(404).json({ error: 'Route or student not found in this institution.' });
    return;
  }
  db.prepare(
    `INSERT INTO transport_assignments (institution_id, route_id, student_id, pickup_stop, status)
     VALUES (?, ?, ?, ?, 'active')
     ON CONFLICT(institution_id, student_id) DO UPDATE SET route_id = excluded.route_id, pickup_stop = excluded.pickup_stop, status = 'active'`
  ).run(tid, d.routeId, d.studentId, sanitizeText(d.pickupStop, 120));
  recordAudit(req, 'TRANSPORT_ASSIGNED', 'transport_assignment', d.studentId, `Assigned student #${d.studentId} to route #${d.routeId}`);
  res.status(201).json({ message: 'Student assigned to transport route.' });
});

router.delete('/transport/assignments/:id', requirePermission('transport.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM transport_assignments WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Transport assignment not found.' });
    return;
  }
  res.json({ message: 'Transport assignment removed.' });
});

/* ============================================================================
 * 5. PARENT MANAGEMENT
 * ========================================================================== */
router.get('/parents', requirePermission('parents.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;
  const parents = db.prepare('SELECT * FROM parents WHERE institution_id = ? ORDER BY id DESC').all(tid) as Record<string, unknown>[];
  const enriched = parents.map((p) => {
    const wards = db
      .prepare(
        `SELECT s.id, s.student_code, s.full_name, ps.relationship
         FROM parent_students ps
         JOIN students s ON s.id = ps.student_id
         WHERE ps.parent_id = ? AND s.institution_id = ?`
      )
      .all(p.id, tid);
    return { ...p, wards };
  });
  res.json({ parents: enriched });
});

router.post('/parents', requirePermission('parents.manage'), (req, res) => {
  const schema = z.object({
    fullName: z.string().min(2).max(120),
    email: z.string().email().max(160),
    phone: z.string().max(30).optional().default(''),
    occupation: z.string().max(80).optional().default(''),
    address: z.string().max(240).optional().default(''),
    studentId: z.coerce.number().int().positive().optional(),
    relationship: z.string().max(40).optional().default('Parent'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid parent data.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  try {
    const r = db
      .prepare(`INSERT INTO parents (institution_id, full_name, email, phone, occupation, address) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(tid, sanitizeText(d.fullName, 120), d.email.trim().toLowerCase(), sanitizeText(d.phone, 30), sanitizeText(d.occupation, 80), sanitizeText(d.address, 240));
    const pid = Number(r.lastInsertRowid);
    if (d.studentId) {
      const st = db.prepare('SELECT id FROM students WHERE id = ? AND institution_id = ?').get(d.studentId, tid);
      if (st) {
        db.prepare('INSERT OR IGNORE INTO parent_students (parent_id, student_id, relationship) VALUES (?, ?, ?)').run(pid, d.studentId, sanitizeText(d.relationship, 40));
      }
    }
    recordAudit(req, 'PARENT_CREATED', 'parent', pid, `Added parent ${d.fullName}`);
    res.status(201).json({ parent: db.prepare('SELECT * FROM parents WHERE id = ?').get(pid) });
  } catch {
    res.status(409).json({ error: 'A parent with this email already exists in this institution.' });
  }
});

router.delete('/parents/:id', requirePermission('parents.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM parents WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Parent record not found.' });
    return;
  }
  recordAudit(req, 'PARENT_DELETED', 'parent', id, 'Deleted parent record');
  res.json({ message: 'Parent deleted.' });
});

/* ============================================================================
 * 6. CERTIFICATES MANAGEMENT
 * ========================================================================== */
router.get('/certificates', requirePermission('certificates.view'), (req, res) => {
  const db = getDb();
  const certificates = db
    .prepare(
      `SELECT cert.*, s.full_name as student_name, s.student_code, s.admission_number,
              c.name as course_name, cl.name as class_name, i.name as institution_name, i.institution_code
       FROM certificates cert
       JOIN students s ON s.id = cert.student_id
       JOIN courses c ON c.id = s.course_id
       JOIN classes cl ON cl.id = s.class_id
       JOIN institutions i ON i.id = cert.institution_id
       WHERE cert.institution_id = ?
       ORDER BY cert.id DESC`
    )
    .all(req.tenantId!);
  res.json({ certificates });
});

router.post('/certificates', requirePermission('certificates.manage'), (req, res) => {
  const schema = z.object({
    studentId: z.coerce.number().int().positive(),
    certificateType: z.enum(['Bonafide', 'Transfer', 'Character', 'Course Completion', 'Merit Award']),
    issueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    remarks: z.string().max(300).optional().default(''),
    signedBy: z.string().max(120).optional().default('Principal / Office of the Registrar'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid certificate input.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const student = db.prepare('SELECT id, full_name FROM students WHERE id = ? AND institution_id = ?').get(d.studentId, tid) as
    | { id: number; full_name: string }
    | undefined;
  if (!student) {
    res.status(404).json({ error: 'Student not found in this institution.' });
    return;
  }
  const certNo = `AVN-CERT-${tid}-${new Date().getFullYear()}-${Date.now().toString().slice(-5)}`;
  const r = db
    .prepare(
      `INSERT INTO certificates (institution_id, certificate_number, student_id, certificate_type, issue_date, remarks, signed_by, status, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'issued', ?)`
    )
    .run(tid, certNo, student.id, d.certificateType, d.issueDate || new Date().toISOString().slice(0, 10), sanitizeText(d.remarks, 300), sanitizeText(d.signedBy, 120), req.user!.id);

  recordAudit(req, 'CERTIFICATE_ISSUED', 'certificate', Number(r.lastInsertRowid), `Issued ${d.certificateType} (${certNo}) for ${student.full_name}`);
  res.status(201).json({ certificate: db.prepare('SELECT * FROM certificates WHERE id = ?').get(r.lastInsertRowid) });
});

router.patch('/certificates/:id/revoke', requirePermission('certificates.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb()
    .prepare(`UPDATE certificates SET status = 'revoked' WHERE id = ? AND institution_id = ?`)
    .run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Certificate not found.' });
    return;
  }
  recordAudit(req, 'CERTIFICATE_REVOKED', 'certificate', id, 'Revoked certificate');
  res.json({ message: 'Certificate revoked.' });
});

router.delete('/certificates/:id', requirePermission('certificates.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM certificates WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Certificate not found.' });
    return;
  }
  recordAudit(req, 'CERTIFICATE_DELETED', 'certificate', id, 'Deleted certificate');
  res.json({ message: 'Certificate removed.' });
});

export default router;
