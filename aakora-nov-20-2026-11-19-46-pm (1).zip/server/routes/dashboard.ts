import { Router } from 'express';
import { getDb } from '../db/connection.ts';
import { requireAuth, requireTenantScope } from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireTenantScope);

router.get('/overview', (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;

  const institution = db.prepare('SELECT * FROM institutions WHERE id = ?').get(tid);
  const totalStudents = (db.prepare("SELECT COUNT(*) as c FROM students WHERE institution_id = ? AND status != 'archived'").get(tid) as { c: number }).c;
  const totalTeachers = (db.prepare("SELECT COUNT(*) as c FROM teachers WHERE institution_id = ? AND status != 'archived'").get(tid) as { c: number }).c;
  const totalStaff = (db.prepare("SELECT COUNT(*) as c FROM staff WHERE institution_id = ? AND status != 'archived'").get(tid) as { c: number }).c;
  const totalParents = (db.prepare('SELECT COUNT(*) as c FROM parents WHERE institution_id = ?').get(tid) as { c: number }).c;

  const attendanceAgg = db
    .prepare(
      `SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
        SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late,
        SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent
       FROM attendance WHERE institution_id = ? AND entity_type = 'student'`
    )
    .get(tid) as { total: number; present: number; late: number; absent: number };

  const attendanceRate =
    attendanceAgg.total > 0 ? Math.round(((attendanceAgg.present + attendanceAgg.late) / attendanceAgg.total) * 1000) / 10 : 0;

  const financeAgg = db
    .prepare(
      `SELECT
        COALESCE(SUM(net_amount), 0) as totalBilled,
        COALESCE(SUM(paid_amount), 0) as totalCollected,
        COALESCE(SUM(CASE WHEN status IN ('pending','partial','overdue') THEN net_amount - paid_amount ELSE 0 END), 0) as totalOutstanding
       FROM fees WHERE institution_id = ?`
    )
    .get(tid) as { totalBilled: number; totalCollected: number; totalOutstanding: number };

  const examAvg = db
    .prepare('SELECT COALESCE(AVG(percentage), 0) as avgScore, COUNT(*) as entries FROM results WHERE institution_id = ?')
    .get(tid) as { avgScore: number; entries: number };

  const libraryAgg = db
    .prepare(
      `SELECT
        (SELECT COALESCE(SUM(total_copies), 0) FROM library_books WHERE institution_id = ?) as totalBooks,
        (SELECT COUNT(*) FROM library_issues WHERE institution_id = ? AND status = 'issued') as activeLoans`
    )
    .get(tid, tid) as { totalBooks: number; activeLoans: number };

  const transportAgg = db
    .prepare(
      `SELECT
        (SELECT COUNT(*) FROM transport_routes WHERE institution_id = ? AND status = 'active') as activeRoutes,
        (SELECT COUNT(*) FROM transport_assignments WHERE institution_id = ? AND status = 'active') as assignedStudents`
    )
    .get(tid, tid) as { activeRoutes: number; assignedStudents: number };

  const enrollmentByCourse = db
    .prepare(
      `SELECT c.code, c.name, COUNT(s.id) as students
       FROM courses c
       LEFT JOIN students s ON s.course_id = c.id AND s.institution_id = c.institution_id AND s.status != 'archived'
       WHERE c.institution_id = ?
       GROUP BY c.id ORDER BY students DESC`
    )
    .all(tid);

  const attendanceByDate = db
    .prepare(
      `SELECT attendance_date as date,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
        SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late,
        SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent
       FROM attendance
       WHERE institution_id = ? AND entity_type = 'student'
       GROUP BY attendance_date
       ORDER BY attendance_date ASC
       LIMIT 14`
    )
    .all(tid);

  const feeStatusBreakdown = db
    .prepare(
      `SELECT status, COUNT(*) as count, COALESCE(SUM(net_amount), 0) as amount
       FROM fees WHERE institution_id = ?
       GROUP BY status`
    )
    .all(tid);

  const gradeDistribution = db
    .prepare(
      `SELECT grade, COUNT(*) as count
       FROM results WHERE institution_id = ?
       GROUP BY grade ORDER BY grade ASC`
    )
    .all(tid);

  const recentNotices = db
    .prepare('SELECT id, title, category, priority, created_at FROM notices WHERE institution_id = ? ORDER BY created_at DESC LIMIT 5')
    .all(tid);

  const recentPayments = db
    .prepare(
      `SELECT p.id, p.receipt_number, p.amount, p.payment_method, p.created_at, s.full_name as student_name
       FROM payments p
       JOIN students s ON s.id = p.student_id
       WHERE p.institution_id = ? AND p.status = 'verified'
       ORDER BY p.created_at DESC LIMIT 6`
    )
    .all(tid);

  res.json({
    institution,
    kpis: {
      totalStudents,
      totalTeachers,
      totalStaff,
      totalParents,
      attendanceRate,
      totalBilled: financeAgg.totalBilled,
      totalCollected: financeAgg.totalCollected,
      totalOutstanding: financeAgg.totalOutstanding,
      averageExamScore: Math.round(examAvg.avgScore * 10) / 10,
      totalBooks: libraryAgg.totalBooks,
      activeLoans: libraryAgg.activeLoans,
      activeRoutes: transportAgg.activeRoutes,
      assignedStudents: transportAgg.assignedStudents,
    },
    charts: {
      enrollmentByCourse,
      attendanceByDate,
      feeStatusBreakdown,
      gradeDistribution,
    },
    recentNotices,
    recentPayments,
  });
});

export default router;
