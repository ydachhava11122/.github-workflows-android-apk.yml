import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  requireTenantScope,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);
router.use(requireTenantScope);

router.get('/overview', requirePermission('fees.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;

  const structures = db
    .prepare(
      `SELECT fs.*, c.name as course_name, c.code as course_code
       FROM fee_structures fs
       JOIN courses c ON c.id = fs.course_id
       WHERE fs.institution_id = ?
       ORDER BY fs.id DESC`
    )
    .all(tid);

  const fees = db
    .prepare(
      `SELECT f.*, s.full_name as student_name, s.student_code, cl.name as class_name
       FROM fees f
       JOIN students s ON s.id = f.student_id
       JOIN classes cl ON cl.id = s.class_id
       WHERE f.institution_id = ?
       ORDER BY f.id DESC`
    )
    .all(tid);

  const payments = db
    .prepare(
      `SELECT p.*, s.full_name as student_name, f.title as fee_title
       FROM payments p
       JOIN students s ON s.id = p.student_id
       JOIN fees f ON f.id = p.fee_id
       WHERE p.institution_id = ?
       ORDER BY p.created_at DESC`
    )
    .all(tid);

  const summary = db
    .prepare(
      `SELECT
        COALESCE(SUM(net_amount), 0) as totalBilled,
        COALESCE(SUM(paid_amount), 0) as totalCollected,
        COALESCE(SUM(CASE WHEN status IN ('pending','partial','overdue') THEN net_amount - paid_amount ELSE 0 END), 0) as totalOutstanding
       FROM fees WHERE institution_id = ?`
    )
    .get(tid);

  res.json({ structures, fees, payments, summary });
});

router.post('/structures', requirePermission('fees.manage'), (req, res) => {
  const schema = z.object({
    courseId: z.coerce.number().int().positive(),
    title: z.string().min(2).max(120),
    category: z.string().max(60).optional().default('Tuition'),
    amount: z.coerce.number().min(0),
    frequency: z.enum(['monthly', 'quarterly', 'semester', 'annual', 'one_time']).optional().default('semester'),
    academicYear: z.string().max(24).optional().default('2026-2027'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid fee structure.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const course = db.prepare('SELECT id FROM courses WHERE id = ? AND institution_id = ?').get(d.courseId, tid);
  if (!course) {
    res.status(400).json({ error: 'Course not found in this institution.' });
    return;
  }
  const r = db
    .prepare(
      `INSERT INTO fee_structures (institution_id, course_id, title, category, amount, frequency, academic_year)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(tid, d.courseId, sanitizeText(d.title, 120), sanitizeText(d.category, 60), d.amount, d.frequency, sanitizeText(d.academicYear, 24));
  recordAudit(req, 'FEE_STRUCTURE_CREATED', 'fee_structure', Number(r.lastInsertRowid), `Created structure ${d.title}`);
  res.status(201).json({ structure: db.prepare('SELECT * FROM fee_structures WHERE id = ?').get(r.lastInsertRowid) });
});

router.post('/fees', requirePermission('fees.manage'), (req, res) => {
  const schema = z.object({
    studentId: z.coerce.number().int().positive(),
    title: z.string().min(2).max(120),
    academicYear: z.string().max(24).optional().default('2026-2027'),
    grossAmount: z.coerce.number().min(0),
    discountAmount: z.coerce.number().min(0).optional().default(0),
    dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid fee invoice.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const student = db.prepare('SELECT id FROM students WHERE id = ? AND institution_id = ?').get(d.studentId, tid);
  if (!student) {
    res.status(404).json({ error: 'Student not found in this institution.' });
    return;
  }
  const net = Math.max(0, d.grossAmount - d.discountAmount);
  const status = net === 0 ? 'waived' : 'pending';
  const r = db
    .prepare(
      `INSERT INTO fees (institution_id, student_id, title, academic_year, gross_amount, discount_amount, net_amount, paid_amount, due_date, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`
    )
    .run(tid, d.studentId, sanitizeText(d.title, 120), sanitizeText(d.academicYear, 24), d.grossAmount, d.discountAmount, net, d.dueDate, status);

  recordAudit(req, 'FEE_INVOICE_CREATED', 'fee', Number(r.lastInsertRowid), `Billed ${d.title} (${net})`);
  res.status(201).json({ fee: db.prepare('SELECT * FROM fees WHERE id = ?').get(r.lastInsertRowid) });
});

router.post('/payments', requirePermission('fees.manage'), (req, res) => {
  const schema = z.object({
    feeId: z.coerce.number().int().positive(),
    amount: z.coerce.number().positive(),
    paymentMethod: z.enum(['bank_transfer', 'card_gateway', 'upi_verified', 'cheque', 'cash_counter']),
    transactionReference: z.string().min(2).max(80),
    notes: z.string().max(200).optional().default(''),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid payment payload.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const fee = db.prepare('SELECT * FROM fees WHERE id = ? AND institution_id = ?').get(d.feeId, tid) as
    | { id: number; student_id: number; net_amount: number; paid_amount: number }
    | undefined;
  if (!fee) {
    res.status(404).json({ error: 'Fee invoice not found in this institution.' });
    return;
  }

  const remaining = Math.max(0, fee.net_amount - fee.paid_amount);
  if (d.amount > remaining + 0.01) {
    res.status(400).json({ error: `Payment exceeds remaining balance (${remaining.toFixed(2)}).` });
    return;
  }

  const receiptNumber = `AVN-RCPT-${tid}-${Date.now().toString().slice(-6)}`;
  let paymentId = 0;
  const tx = db.transaction(() => {
    const r = db
      .prepare(
        `INSERT INTO payments (
          institution_id, fee_id, student_id, receipt_number, amount, payment_method,
          verification_source, transaction_reference, verified_by, verified_at, status, notes
        ) VALUES (?, ?, ?, ?, ?, ?, 'authorized_manual', ?, ?, datetime('now'), 'verified', ?)`
      )
      .run(tid, fee.id, fee.student_id, receiptNumber, d.amount, d.paymentMethod, sanitizeText(d.transactionReference, 80), req.user!.id, sanitizeText(d.notes, 200));
    paymentId = Number(r.lastInsertRowid);

    const newPaid = Math.round((fee.paid_amount + d.amount) * 100) / 100;
    const newStatus = newPaid >= fee.net_amount ? 'paid' : 'partial';
    db.prepare(`UPDATE fees SET paid_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`).run(newPaid, newStatus, fee.id);
  });
  tx();

  recordAudit(req, 'PAYMENT_RECORDED', 'payment', paymentId, `Verified payment ${receiptNumber} (${d.amount})`);
  res.status(201).json({ payment: db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) });
});

router.delete('/fees/:id', requirePermission('fees.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const r = db.prepare('DELETE FROM fees WHERE id = ? AND institution_id = ?').run(id, tid);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Fee invoice not found in this institution.' });
    return;
  }
  recordAudit(req, 'FEE_DELETED', 'fee', id, 'Deleted fee invoice');
  res.json({ message: 'Fee invoice removed.' });
});

export default router;
