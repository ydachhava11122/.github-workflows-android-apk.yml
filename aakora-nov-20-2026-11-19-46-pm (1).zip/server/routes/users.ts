import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import { hashPassword, validatePasswordPolicy } from '../security/crypto.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);

router.get('/users', requirePermission('users.manage'), (req, res) => {
  const db = getDb();
  const requestedInst = req.headers['x-institution-id'] ? Number(req.headers['x-institution-id']) : null;

  let users: unknown[];
  if (req.user!.isFounder) {
    if (requestedInst && Number.isFinite(requestedInst)) {
      users = db
        .prepare(
          `SELECT u.id, u.institution_id, u.username, u.email, u.mobile, u.full_name, u.status, u.last_login_at, u.created_at,
                  r.code as role_code, r.name as role_name, i.name as institution_name
           FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN institutions i ON i.id = u.institution_id
           WHERE u.institution_id = ? OR u.institution_id IS NULL
           ORDER BY u.id DESC`
        )
        .all(requestedInst);
    } else {
      users = db
        .prepare(
          `SELECT u.id, u.institution_id, u.username, u.email, u.mobile, u.full_name, u.status, u.last_login_at, u.created_at,
                  r.code as role_code, r.name as role_name, i.name as institution_name
           FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN institutions i ON i.id = u.institution_id
           ORDER BY u.id DESC`
        )
        .all();
    }
  } else {
    users = db
      .prepare(
        `SELECT u.id, u.institution_id, u.username, u.email, u.mobile, u.full_name, u.status, u.last_login_at, u.created_at,
                r.code as role_code, r.name as role_name, i.name as institution_name
         FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN institutions i ON i.id = u.institution_id
         WHERE u.institution_id = ?
         ORDER BY u.id DESC`
      )
      .all(req.user!.institutionId);
  }

  const roles = db
    .prepare(
      req.user!.isFounder
        ? 'SELECT id, code, name, description FROM roles ORDER BY hierarchy_level DESC'
        : "SELECT id, code, name, description FROM roles WHERE code != 'FOUNDER_SUPER_ADMIN' ORDER BY hierarchy_level DESC"
    )
    .all();

  res.json({ users, roles });
});

router.post('/users', requirePermission('users.manage'), (req, res) => {
  const schema = z.object({
    fullName: z.string().min(2).max(120),
    username: z.string().min(3).max(50).regex(/^[a-zA-Z0-9._-]+$/),
    email: z.string().email().max(160),
    mobile: z.string().max(30).optional().default(''),
    roleCode: z.string().min(2).max(40),
    password: z.string().min(8).max(128),
    institutionId: z.coerce.number().int().positive().nullable().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid user payload.' });
    return;
  }

  const d = parsed.data;
  const policy = validatePasswordPolicy(d.password);
  if (!policy.valid) {
    res.status(400).json({ error: policy.errors.join(' ') });
    return;
  }

  if (!req.user!.isFounder && d.roleCode === 'FOUNDER_SUPER_ADMIN') {
    res.status(403).json({ error: 'Only the Founder Super Admin can assign Founder roles.' });
    return;
  }

  const db = getDb();
  const role = db.prepare('SELECT id, code FROM roles WHERE code = ?').get(d.roleCode) as { id: number; code: string } | undefined;
  if (!role) {
    res.status(400).json({ error: 'Invalid role selected.' });
    return;
  }

  const targetInstId = req.user!.isFounder
    ? role.code === 'FOUNDER_SUPER_ADMIN'
      ? null
      : d.institutionId || (req.headers['x-institution-id'] ? Number(req.headers['x-institution-id']) : null)
    : req.user!.institutionId;

  if (role.code !== 'FOUNDER_SUPER_ADMIN' && !targetInstId) {
    res.status(400).json({ error: 'An institution must be assigned for non-Founder accounts.' });
    return;
  }

  try {
    const r = db
      .prepare(
        `INSERT INTO users (institution_id, username, email, mobile, full_name, password_hash, role_id, status, email_verified)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'active', 1)`
      )
      .run(
        targetInstId,
        d.username.trim().toLowerCase(),
        d.email.trim().toLowerCase(),
        sanitizeText(d.mobile, 30),
        sanitizeText(d.fullName, 120),
        hashPassword(d.password),
        role.id
      );
    const id = Number(r.lastInsertRowid);
    recordAudit(req, 'USER_CREATED', 'user', id, `Created account ${d.email} (${role.code})`);
    res.status(201).json({ id, message: `User ${d.fullName} created.` });
  } catch {
    res.status(409).json({ error: 'A user with that email or username already exists.' });
  }
});

router.patch('/users/:id/status', requirePermission('users.manage'), (req, res) => {
  const id = Number(req.params.id);
  const status = req.body?.status;
  if (!['active', 'suspended', 'inactive'].includes(status)) {
    res.status(400).json({ error: 'Invalid status value.' });
    return;
  }
  if (id === req.user!.id) {
    res.status(400).json({ error: 'You cannot suspend your own currently signed-in account.' });
    return;
  }
  const db = getDb();
  const target = db.prepare('SELECT id, institution_id, email FROM users WHERE id = ?').get(id) as
    | { id: number; institution_id: number | null; email: string }
    | undefined;
  if (!target) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  if (!req.user!.isFounder && target.institution_id !== req.user!.institutionId) {
    res.status(403).json({ error: 'Cannot modify users belonging to another institution.' });
    return;
  }
  db.prepare(`UPDATE users SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(status, id);
  if (status !== 'active') {
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
  }
  recordAudit(req, 'USER_STATUS_CHANGED', 'user', id, `${target.email} -> ${status}`);
  res.json({ message: `User account status set to ${status}.` });
});

router.get('/audit-logs', requirePermission('audit.view'), (req, res) => {
  const db = getDb();
  const logs = req.user!.isFounder
    ? db
        .prepare(
          `SELECT a.*, i.name as institution_name
           FROM audit_logs a LEFT JOIN institutions i ON i.id = a.institution_id
           ORDER BY a.created_at DESC LIMIT 120`
        )
        .all()
    : db
        .prepare(
          `SELECT a.*, i.name as institution_name
           FROM audit_logs a LEFT JOIN institutions i ON i.id = a.institution_id
           WHERE a.institution_id = ?
           ORDER BY a.created_at DESC LIMIT 120`
        )
        .all(req.user!.institutionId);

  const loginHistory = req.user!.isFounder
    ? db
        .prepare(
          `SELECT lh.*, i.name as institution_name
           FROM login_history lh LEFT JOIN institutions i ON i.id = lh.institution_id
           ORDER BY lh.created_at DESC LIMIT 80`
        )
        .all()
    : db
        .prepare(
          `SELECT lh.*, i.name as institution_name
           FROM login_history lh LEFT JOIN institutions i ON i.id = lh.institution_id
           WHERE lh.institution_id = ?
           ORDER BY lh.created_at DESC LIMIT 80`
        )
        .all(req.user!.institutionId);

  res.json({ logs, loginHistory });
});

export default router;
