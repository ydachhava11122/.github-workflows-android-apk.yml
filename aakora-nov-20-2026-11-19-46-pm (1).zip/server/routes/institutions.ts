import { Router } from 'express';
import fs from 'fs';
import { z } from 'zod';
import { getDb, getDbPath } from '../db/connection.ts';
import { hashPassword, validatePasswordPolicy } from '../security/crypto.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requireFounder,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
const bootTime = Date.now();

router.use(requireAuth);
router.use(requireCsrf);

/**
 * Founder Super Admin Centralized Command Dashboard
 */
router.get('/founder-dashboard', requireFounder, (_req, res) => {
  const db = getDb();

  const totalInstitutions = (db.prepare('SELECT COUNT(*) as c FROM institutions').get() as { c: number }).c;
  const activeInstitutions = (db.prepare("SELECT COUNT(*) as c FROM institutions WHERE status = 'active'").get() as { c: number }).c;
  const suspendedInstitutions = (db.prepare("SELECT COUNT(*) as c FROM institutions WHERE status = 'suspended'").get() as { c: number }).c;
  const totalStudents = (db.prepare("SELECT COUNT(*) as c FROM students WHERE status != 'archived'").get() as { c: number }).c;
  const totalTeachers = (db.prepare("SELECT COUNT(*) as c FROM teachers WHERE status != 'archived'").get() as { c: number }).c;
  const totalAdministrators = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM users u
         JOIN roles r ON r.id = u.role_id
         WHERE r.code IN ('FOUNDER_SUPER_ADMIN','INSTITUTION_ADMIN','PRINCIPAL') AND u.status = 'active'`
      )
      .get() as { c: number }
  ).c;

  const licenseRevenue = (db.prepare("SELECT COALESCE(SUM(annual_license_fee), 0) as s FROM institutions WHERE status = 'active'").get() as { s: number }).s;
  const collectedTuition = (db.prepare("SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE status = 'verified'").get() as { s: number }).s;
  const pendingTuition = (db.prepare("SELECT COALESCE(SUM(net_amount - paid_amount), 0) as s FROM fees WHERE status IN ('pending','partial','overdue')").get() as { s: number }).s;

  const institutionBreakdown = db
    .prepare(
      `
    SELECT
      i.id, i.institution_code, i.name, i.short_name, i.city, i.subscription_plan,
      i.annual_license_fee, i.status, i.created_at,
      (SELECT COUNT(*) FROM students s WHERE s.institution_id = i.id AND s.status != 'archived') as student_count,
      (SELECT COUNT(*) FROM teachers t WHERE t.institution_id = i.id AND t.status != 'archived') as teacher_count,
      (SELECT COUNT(*) FROM users u WHERE u.institution_id = i.id AND u.status = 'active') as user_count,
      (SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE p.institution_id = i.id AND p.status = 'verified') as collected_fees
    FROM institutions i
    ORDER BY i.created_at DESC
  `
    )
    .all();

  const recentRegistrations = db
    .prepare(
      `
    SELECT u.id, u.full_name, u.email, u.status, u.created_at, r.name as role_name, i.name as institution_name
    FROM users u
    JOIN roles r ON r.id = u.role_id
    LEFT JOIN institutions i ON i.id = u.institution_id
    ORDER BY u.created_at DESC
    LIMIT 8
  `
    )
    .all();

  const systemActivity = db
    .prepare(
      `
    SELECT a.id, a.actor_name, a.actor_role, a.action, a.resource_type, a.details, a.ip_address, a.created_at, i.name as institution_name
    FROM audit_logs a
    LEFT JOIN institutions i ON i.id = a.institution_id
    ORDER BY a.created_at DESC
    LIMIT 12
  `
    )
    .all();

  const recentLogins = db
    .prepare(
      `
    SELECT lh.id, lh.identifier, lh.outcome, lh.ip_address, lh.reason, lh.created_at, i.name as institution_name
    FROM login_history lh
    LEFT JOIN institutions i ON i.id = lh.institution_id
    ORDER BY lh.created_at DESC
    LIMIT 10
  `
    )
    .all();

  const recentNotifications = db
    .prepare(
      `SELECT id, title, content, category, priority, created_at FROM notices ORDER BY created_at DESC LIMIT 6`
    )
    .all();

  const dbPath = getDbPath();
  const dbSizeBytes = fs.existsSync(dbPath) ? fs.statSync(dbPath).size : 0;
  const backupCount = (db.prepare('SELECT COUNT(*) as c FROM backups').get() as { c: number }).c;
  const lastBackup = db.prepare('SELECT filename, created_at, status FROM backups ORDER BY created_at DESC LIMIT 1').get();
  const activeSessions = (db.prepare("SELECT COUNT(*) as c FROM sessions WHERE expires_at > datetime('now')").get() as { c: number }).c;

  res.json({
    kpis: {
      totalInstitutions,
      activeInstitutions,
      suspendedInstitutions,
      totalStudents,
      totalTeachers,
      totalAdministrators,
      licenseRevenue,
      collectedTuition,
      pendingTuition,
    },
    institutionBreakdown,
    recentRegistrations,
    systemActivity,
    recentLogins,
    recentNotifications,
    systemHealth: {
      status: 'Healthy',
      databaseEngine: 'SQLite WAL (PostgreSQL Production Ready)',
      dbSizeBytes,
      uptimeSeconds: Math.floor((Date.now() - bootTime) / 1000),
      activeSessions,
      backupCount,
      lastBackup: lastBackup || null,
      tenantIsolation: 'Strict Server-Side Enforcement',
    },
  });
});

/**
 * List institutions (Founder sees all; tenant users see only their own institution)
 */
router.get('/', (req, res) => {
  const db = getDb();
  if (req.user!.isFounder) {
    const rows = db
      .prepare(
        `
      SELECT
        i.*,
        (SELECT COUNT(*) FROM students s WHERE s.institution_id = i.id AND s.status != 'archived') as student_count,
        (SELECT COUNT(*) FROM teachers t WHERE t.institution_id = i.id AND t.status != 'archived') as teacher_count,
        (SELECT COUNT(*) FROM staff st WHERE st.institution_id = i.id AND st.status != 'archived') as staff_count,
        (SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE p.institution_id = i.id AND p.status = 'verified') as collected_fees,
        (SELECT u.email FROM users u JOIN roles r ON r.id = u.role_id WHERE u.institution_id = i.id AND r.code = 'INSTITUTION_ADMIN' LIMIT 1) as admin_email
      FROM institutions i
      ORDER BY i.id ASC
    `
      )
      .all();
    res.json({ institutions: rows });
    return;
  }

  const own = db.prepare('SELECT * FROM institutions WHERE id = ?').all(req.user!.institutionId);
  res.json({ institutions: own });
});

const createInstitutionSchema = z.object({
  name: z.string().min(2).max(160),
  shortName: z.string().min(2).max(16).optional(),
  email: z.string().email().max(160),
  phone: z.string().max(40).optional().default(''),
  address: z.string().max(240).optional().default(''),
  city: z.string().max(100).optional().default(''),
  country: z.string().max(80).optional().default('United States'),
  academicYear: z.string().max(30).optional().default('2026-2027'),
  currencySymbol: z.string().max(4).optional().default('$'),
  subscriptionPlan: z.enum(['Standard', 'Professional', 'Enterprise']).optional().default('Enterprise'),
  annualLicenseFee: z.coerce.number().min(0).optional().default(18000),
  adminFullName: z.string().min(2).max(120),
  adminEmail: z.string().email().max(160),
  adminUsername: z.string().min(3).max(50).regex(/^[a-zA-Z0-9._-]+$/),
  adminPassword: z.string().min(8).max(128),
});

router.post('/', requireFounder, (req, res) => {
  const parsed = createInstitutionSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid institution payload.' });
    return;
  }

  const d = parsed.data;
  const policy = validatePasswordPolicy(d.adminPassword);
  if (!policy.valid) {
    res.status(400).json({ error: `Admin password policy error: ${policy.errors.join(' ')}` });
    return;
  }

  const db = getDb();
  const cleanAdminEmail = d.adminEmail.trim().toLowerCase();
  const cleanAdminUser = d.adminUsername.trim().toLowerCase();
  const dup = db
    .prepare('SELECT id FROM users WHERE lower(email) = ? OR lower(username) = ?')
    .get(cleanAdminEmail, cleanAdminUser);
  if (dup) {
    res.status(409).json({ error: 'An account with that admin email or username already exists.' });
    return;
  }

  const adminRole = db.prepare("SELECT id FROM roles WHERE code = 'INSTITUTION_ADMIN'").get() as { id: number };
  const countRow = db.prepare('SELECT COUNT(*) as c FROM institutions').get() as { c: number };
  const instCode = `AVN-INST-${1001 + countRow.c + Math.floor(Math.random() * 90)}`;
  const shortName = sanitizeText(d.shortName || d.name.split(' ').map((w) => w[0]).join('').toUpperCase(), 12) || 'INST';

  let createdId = 0;
  const tx = db.transaction(() => {
    const instRes = db
      .prepare(
        `INSERT INTO institutions (
          institution_code, name, short_name, email, phone, address, city, country,
          academic_year, currency_symbol, subscription_plan, annual_license_fee, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`
      )
      .run(
        instCode,
        sanitizeText(d.name, 160),
        shortName,
        d.email.trim().toLowerCase(),
        sanitizeText(d.phone, 40),
        sanitizeText(d.address, 240),
        sanitizeText(d.city, 100),
        sanitizeText(d.country, 80),
        sanitizeText(d.academicYear, 30),
        sanitizeText(d.currencySymbol, 4) || '$',
        d.subscriptionPlan,
        d.annualLicenseFee
      );
    createdId = Number(instRes.lastInsertRowid);

    // Create dedicated Institution Admin
    db.prepare(
      `INSERT INTO users (institution_id, username, email, mobile, full_name, password_hash, role_id, status, email_verified)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'active', 1)`
    ).run(createdId, cleanAdminUser, cleanAdminEmail, sanitizeText(d.phone, 40), sanitizeText(d.adminFullName, 120), hashPassword(d.adminPassword), adminRole.id);

    // Bootstrap 1 default academic course, class, and subject so the institution is immediately operational
    const cRes = db
      .prepare(
        `INSERT INTO courses (institution_id, code, name, department, duration_months, annual_tuition)
         VALUES (?, 'GEN-101', 'General Academic Program', 'Academic Affairs', 12, 10000)`
      )
      .run(createdId);
    const courseId = Number(cRes.lastInsertRowid);
    db.prepare(
      `INSERT INTO classes (institution_id, course_id, name, section, academic_year, room_number, capacity)
       VALUES (?, ?, 'Cohort 1', 'A', ?, 'Room 101', 40)`
    ).run(createdId, courseId, sanitizeText(d.academicYear, 30));
    db.prepare(
      `INSERT INTO subjects (institution_id, course_id, code, name, max_marks, pass_marks, credits)
       VALUES (?, ?, 'CORE-101', 'Core Curriculum Foundations', 100, 40, 4)`
    ).run(createdId, courseId);
  });
  tx();

  const institution = db.prepare('SELECT * FROM institutions WHERE id = ?').get(createdId);
  recordAudit(req, 'INSTITUTION_CREATED', 'institution', createdId, `Provisioned ${d.name} (${instCode}) with admin ${cleanAdminEmail}`);
  res.status(201).json({ institution, message: `Institution ${d.name} (${instCode}) provisioned successfully.` });
});

router.put('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!req.user!.isFounder && req.user!.institutionId !== id) {
    res.status(403).json({ error: 'You cannot edit another institution.' });
    return;
  }
  const db = getDb();
  const existing = db.prepare('SELECT * FROM institutions WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Institution not found.' });
    return;
  }

  const name = req.body.name ? sanitizeText(req.body.name, 160) : String(existing.name);
  const email = req.body.email ? String(req.body.email).trim().toLowerCase() : String(existing.email);
  const phone = req.body.phone !== undefined ? sanitizeText(req.body.phone, 40) : String(existing.phone);
  const address = req.body.address !== undefined ? sanitizeText(req.body.address, 240) : String(existing.address);
  const city = req.body.city !== undefined ? sanitizeText(req.body.city, 100) : String(existing.city);
  const academicYear = req.body.academicYear ? sanitizeText(req.body.academicYear, 30) : String(existing.academic_year);
  const currencySymbol = req.body.currencySymbol ? sanitizeText(req.body.currencySymbol, 4) : String(existing.currency_symbol);
  const subscriptionPlan =
    req.user!.isFounder && ['Standard', 'Professional', 'Enterprise'].includes(req.body.subscriptionPlan)
      ? req.body.subscriptionPlan
      : String(existing.subscription_plan);
  const annualLicenseFee =
    req.user!.isFounder && req.body.annualLicenseFee !== undefined
      ? Math.max(0, Number(req.body.annualLicenseFee))
      : Number(existing.annual_license_fee);

  db.prepare(
    `UPDATE institutions
     SET name = ?, email = ?, phone = ?, address = ?, city = ?, academic_year = ?, currency_symbol = ?,
         subscription_plan = ?, annual_license_fee = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(name, email, phone, address, city, academicYear, currencySymbol, subscriptionPlan, annualLicenseFee, id);

  recordAudit(req, 'INSTITUTION_UPDATED', 'institution', id, `Updated institution profile for ${name}`);
  res.json({ institution: db.prepare('SELECT * FROM institutions WHERE id = ?').get(id) });
});

router.patch('/:id/status', requireFounder, (req, res) => {
  const id = Number(req.params.id);
  const status = req.body?.status;
  if (!['active', 'suspended'].includes(status)) {
    res.status(400).json({ error: 'Status must be active or suspended.' });
    return;
  }
  const db = getDb();
  const inst = db.prepare('SELECT id, name FROM institutions WHERE id = ?').get(id) as { id: number; name: string } | undefined;
  if (!inst) {
    res.status(404).json({ error: 'Institution not found.' });
    return;
  }
  db.prepare(`UPDATE institutions SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(status, id);
  if (status === 'suspended') {
    // Immediately revoke active sessions belonging to users of the suspended institution
    db.prepare(`DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE institution_id = ?)`).run(id);
  }
  recordAudit(req, 'INSTITUTION_STATUS_CHANGED', 'institution', id, `${inst.name} set to ${status}`);
  res.json({ message: `${inst.name} is now ${status}.`, status });
});

router.delete('/:id', requireFounder, (req, res) => {
  const id = Number(req.params.id);
  const db = getDb();
  const inst = db.prepare('SELECT id, name FROM institutions WHERE id = ?').get(id) as { id: number; name: string } | undefined;
  if (!inst) {
    res.status(404).json({ error: 'Institution not found.' });
    return;
  }
  db.prepare('DELETE FROM institutions WHERE id = ?').run(id);
  recordAudit(req, 'INSTITUTION_DELETED', 'institution', id, `Deleted institution ${inst.name}`);
  res.json({ message: `Institution ${inst.name} removed permanently.` });
});

export default router;
