import type { NextFunction, Request, Response } from 'express';
import { getDb } from '../db/connection.ts';
import { sha256 } from './crypto.ts';

export interface AuthUser {
  id: number;
  institutionId: number | null;
  institutionCode: string | null;
  institutionName: string | null;
  username: string;
  email: string;
  mobile: string;
  fullName: string;
  roleId: number;
  roleCode: string;
  roleName: string;
  isFounder: boolean;
  status: string;
  theme: string;
  language: string;
  notifyEmail: boolean;
  notifyPush: boolean;
  emailVerified: boolean;
  permissions: string[];
  csrfToken: string;
  studentId: number | null;
  teacherId: number | null;
  parentId: number | null;
  linkedStudentIds: number[];
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      sessionTokenHash?: string;
      tenantId?: number;
    }
  }
}

export const SESSION_COOKIE_NAME = 'aaknova_session';

const rateBuckets = new Map<string, number[]>();

export function rateLimit(prefix: string, maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = getClientIp(req);
    const key = `${prefix}:${ip}`;
    const now = Date.now();
    const cutoff = now - windowMs;
    const timestamps = (rateBuckets.get(key) || []).filter((t) => t > cutoff);
    if (timestamps.length >= maxRequests) {
      const retryAfterSec = Math.ceil((timestamps[0] + windowMs - now) / 1000);
      res.setHeader('Retry-After', String(Math.max(1, retryAfterSec)));
      res.status(429).json({
        error: `Too many requests. Please retry after ${Math.max(1, retryAfterSec)} seconds.`,
      });
      return;
    }
    timestamps.push(now);
    rateBuckets.set(key, timestamps);
    next();
  };
}

export function getClientIp(req: Request): string {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length > 0) {
    return fwd.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || '127.0.0.1';
}

export function sanitizeText(value: unknown, maxLen = 500): string {
  if (typeof value !== 'string') return '';
  return value.replace(/[<>]/g, '').trim().slice(0, maxLen);
}

export function recordAudit(
  req: Request,
  action: string,
  resourceType: string,
  resourceId: string | number = '',
  details = '',
  actorOverride?: { id?: number | null; name: string; role: string; institutionId?: number | null }
): void {
  try {
    const db = getDb();
    const actorId = actorOverride ? actorOverride.id ?? null : req.user?.id ?? null;
    const actorName = actorOverride ? actorOverride.name : req.user?.fullName || 'Anonymous';
    const actorRole = actorOverride ? actorOverride.role : req.user?.roleCode || 'SYSTEM';
    const instId =
      actorOverride && actorOverride.institutionId !== undefined
        ? actorOverride.institutionId
        : req.tenantId ?? req.user?.institutionId ?? null;
    db.prepare(
      `INSERT INTO audit_logs (institution_id, user_id, actor_name, actor_role, action, resource_type, resource_id, details, ip_address)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(instId, actorId, actorName, actorRole, action, resourceType, String(resourceId), details, getClientIp(req));
  } catch {
    // Audit logging should never interrupt request processing
  }
}

export function recordLoginHistory(
  req: Request,
  params: {
    userId?: number | null;
    institutionId?: number | null;
    identifier: string;
    outcome: 'success' | 'failed' | 'locked' | 'suspended';
    reason?: string;
  }
): void {
  try {
    const db = getDb();
    db.prepare(
      `INSERT INTO login_history (user_id, institution_id, identifier, outcome, ip_address, user_agent, reason)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(
      params.userId ?? null,
      params.institutionId ?? null,
      params.identifier.slice(0, 120),
      params.outcome,
      getClientIp(req),
      String(req.headers['user-agent'] || '').slice(0, 240),
      params.reason || ''
    );
  } catch {
    // Non-blocking login history write
  }
}

export function loadAuthUserFromSession(rawToken: string): { user: AuthUser; tokenHash: string } | null {
  const db = getDb();
  const tokenHash = sha256(rawToken);
  const row = db
    .prepare(
      `
    SELECT
      s.csrf_token, s.expires_at,
      u.id, u.institution_id, u.username, u.email, u.mobile, u.full_name, u.role_id, u.status,
      u.theme, u.language, u.notify_email, u.notify_push, u.email_verified,
      r.code as role_code, r.name as role_name,
      i.institution_code, i.name as institution_name, i.status as institution_status
    FROM sessions s
    JOIN users u ON u.id = s.user_id
    JOIN roles r ON r.id = u.role_id
    LEFT JOIN institutions i ON i.id = u.institution_id
    WHERE s.token_hash = ?
  `
    )
    .get(tokenHash) as Record<string, unknown> | undefined;

  if (!row) return null;

  const expiresAt = new Date(String(row.expires_at)).getTime();
  if (Number.isNaN(expiresAt) || expiresAt < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
    return null;
  }

  if (row.status !== 'active') {
    return null;
  }

  const roleCode = String(row.role_code);
  const isFounder = roleCode === 'FOUNDER_SUPER_ADMIN';

  // Block non-founder users if their institution has been suspended by the Founder
  if (!isFounder && row.institution_id && row.institution_status === 'suspended') {
    return null;
  }

  const userId = Number(row.id);
  const roleId = Number(row.role_id);

  const perms = (
    db
      .prepare(
        `
      SELECT p.code FROM permissions p
      JOIN role_permissions rp ON rp.permission_id = p.id
      WHERE rp.role_id = ?
    `
      )
      .all(roleId) as { code: string }[]
  ).map((p) => p.code);

  const studentRow = db.prepare('SELECT id FROM students WHERE user_id = ?').get(userId) as { id: number } | undefined;
  const teacherRow = db.prepare('SELECT id FROM teachers WHERE user_id = ?').get(userId) as { id: number } | undefined;
  const parentRow = db.prepare('SELECT id FROM parents WHERE user_id = ?').get(userId) as { id: number } | undefined;

  let linkedStudentIds: number[] = [];
  if (parentRow) {
    linkedStudentIds = (
      db.prepare('SELECT student_id FROM parent_students WHERE parent_id = ?').all(parentRow.id) as { student_id: number }[]
    ).map((r) => r.student_id);
  } else if (studentRow) {
    linkedStudentIds = [studentRow.id];
  }

  return {
    tokenHash,
    user: {
      id: userId,
      institutionId: row.institution_id ? Number(row.institution_id) : null,
      institutionCode: row.institution_code ? String(row.institution_code) : null,
      institutionName: row.institution_name ? String(row.institution_name) : null,
      username: String(row.username),
      email: String(row.email),
      mobile: String(row.mobile || ''),
      fullName: String(row.full_name),
      roleId,
      roleCode,
      roleName: String(row.role_name),
      isFounder,
      status: String(row.status),
      theme: String(row.theme || 'dark'),
      language: String(row.language || 'en'),
      notifyEmail: Boolean(row.notify_email),
      notifyPush: Boolean(row.notify_push),
      emailVerified: Boolean(row.email_verified),
      permissions: perms,
      csrfToken: String(row.csrf_token),
      studentId: studentRow?.id ?? null,
      teacherId: teacherRow?.id ?? null,
      parentId: parentRow?.id ?? null,
      linkedStudentIds,
    },
  };
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const token = req.cookies?.[SESSION_COOKIE_NAME];
  if (!token || typeof token !== 'string') {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }
  const loaded = loadAuthUserFromSession(token);
  if (!loaded) {
    res.clearCookie(SESSION_COOKIE_NAME);
    res.status(401).json({ error: 'Session expired, suspended, or invalid. Please sign in again.' });
    return;
  }
  req.user = loaded.user;
  req.sessionTokenHash = loaded.tokenHash;
  next();
}

export function requireCsrf(req: Request, res: Response, next: NextFunction): void {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    next();
    return;
  }
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  const headerToken = req.headers['x-csrf-token'];
  if (!headerToken || headerToken !== req.user.csrfToken) {
    res.status(403).json({ error: 'Invalid or missing CSRF verification token.' });
    return;
  }
  next();
}

export function requireFounder(req: Request, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  if (!req.user.isFounder) {
    recordAudit(req, 'FOUNDER_ACCESS_DENIED', 'founder', '', `Blocked non-founder access to ${req.originalUrl}`);
    res.status(403).json({ error: 'Founder Super Admin clearance is required for this operation.' });
    return;
  }
  next();
}

/**
 * Enforces strict multi-tenant data isolation on every institutional API route.
 * - Non-founder users are cryptographically pinned to req.user.institutionId.
 * - Any cross-tenant header/query attempt by a non-founder is rejected with 403 and logged.
 * - Founder Super Admin selects active institution context via X-Institution-Id header or query.
 */
export function requireTenantScope(req: Request, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  const db = getDb();
  const requestedRaw = req.headers['x-institution-id'] || req.query.institutionId;
  const requestedId = requestedRaw ? Number(requestedRaw) : null;

  if (!req.user.isFounder) {
    if (!req.user.institutionId) {
      res.status(403).json({ error: 'Account is not bound to an active institution tenant.' });
      return;
    }
    if (requestedId && Number.isFinite(requestedId) && requestedId !== req.user.institutionId) {
      recordAudit(
        req,
        'TENANT_ISOLATION_VIOLATION',
        'institution',
        String(requestedId),
        `User from institution #${req.user.institutionId} attempted cross-tenant access to #${requestedId}`
      );
      res.status(403).json({ error: 'Cross-tenant access denied. Institutions cannot access other institutions’ data.' });
      return;
    }
    req.tenantId = req.user.institutionId;
    next();
    return;
  }

  // Founder context resolution
  if (requestedId && Number.isFinite(requestedId)) {
    const inst = db.prepare('SELECT id FROM institutions WHERE id = ?').get(requestedId) as { id: number } | undefined;
    if (!inst) {
      res.status(404).json({ error: 'Selected institution does not exist.' });
      return;
    }
    req.tenantId = inst.id;
    next();
    return;
  }

  const firstInst = db.prepare('SELECT id FROM institutions ORDER BY id ASC LIMIT 1').get() as { id: number } | undefined;
  if (!firstInst) {
    res.status(400).json({ error: 'No institution exists yet. Create an institution first in the Founder Console.' });
    return;
  }
  req.tenantId = firstInst.id;
  next();
}

export function requirePermission(permissionCode: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (req.user.isFounder || req.user.permissions.includes(permissionCode)) {
      next();
      return;
    }
    recordAudit(req, 'ACCESS_DENIED', 'permission', permissionCode, `Denied access to ${req.method} ${req.originalUrl}`);
    res.status(403).json({ error: `Insufficient permissions: requires ${permissionCode}.` });
  };
}

export function canAccessStudent(user: AuthUser, studentId: number): boolean {
  if (['FOUNDER_SUPER_ADMIN', 'INSTITUTION_ADMIN', 'PRINCIPAL', 'TEACHER', 'ACCOUNTANT', 'STAFF'].includes(user.roleCode)) {
    return true;
  }
  if (user.roleCode === 'STUDENT') {
    return user.studentId === studentId;
  }
  if (user.roleCode === 'PARENT') {
    return user.linkedStudentIds.includes(studentId);
  }
  return false;
}
