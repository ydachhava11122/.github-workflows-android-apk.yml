import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const SCRYPT_KEYLEN = 64;
const SCRYPT_COST = 16384;
const SCRYPT_BLOCK_SIZE = 8;
const SCRYPT_PARALLELIZATION = 1;

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, SCRYPT_KEYLEN, {
    N: SCRYPT_COST,
    r: SCRYPT_BLOCK_SIZE,
    p: SCRYPT_PARALLELIZATION,
  });
  return `scrypt$${SCRYPT_COST}$${SCRYPT_BLOCK_SIZE}$${SCRYPT_PARALLELIZATION}$${salt}$${derived.toString('hex')}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const parts = storedHash.split('$');
    if (parts.length !== 6 || parts[0] !== 'scrypt') {
      return false;
    }
    const N = parseInt(parts[1], 10);
    const r = parseInt(parts[2], 10);
    const p = parseInt(parts[3], 10);
    const salt = parts[4];
    const expectedHex = parts[5];
    const derived = crypto.scryptSync(password, salt, SCRYPT_KEYLEN, { N, r, p });
    const expected = Buffer.from(expectedHex, 'hex');
    if (derived.length !== expected.length) return false;
    return crypto.timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

export function generateSecureToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

export function generateStrongPassword(length = 14): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghijkmnopqrstuvwxyz';
  const digits = '23456789';
  const symbols = '!@#$%^&*-_';
  const all = upper + lower + digits + symbols;
  const pick = (charset: string) => charset[crypto.randomInt(0, charset.length)];
  const chars = [pick(upper), pick(lower), pick(digits), pick(symbols)];
  for (let i = chars.length; i < length; i++) {
    chars.push(pick(all));
  }
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join('');
}

export function sha256(input: string | Buffer): string {
  return crypto.createHash('sha256').update(input).digest('hex');
}

export function validatePasswordPolicy(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  if (password.length < 8) errors.push('Must be at least 8 characters long.');
  if (!/[A-Z]/.test(password)) errors.push('Must include at least one uppercase letter.');
  if (!/[a-z]/.test(password)) errors.push('Must include at least one lowercase letter.');
  if (!/[0-9]/.test(password)) errors.push('Must include at least one number.');
  if (!/[^A-Za-z0-9]/.test(password)) errors.push('Must include at least one special character.');
  return { valid: errors.length === 0, errors };
}

let cachedSessionSecret: string | null = null;

export function getSessionSecret(): string {
  if (cachedSessionSecret) return cachedSessionSecret;
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET !== 'REPLACE_WITH_64_CHAR_HEX_SECRET') {
    cachedSessionSecret = process.env.SESSION_SECRET;
    return cachedSessionSecret;
  }
  const dataDir = path.resolve(process.cwd(), 'data');
  fs.mkdirSync(dataDir, { recursive: true });
  const secretPath = path.join(dataDir, '.session_secret');
  if (fs.existsSync(secretPath)) {
    cachedSessionSecret = fs.readFileSync(secretPath, 'utf8').trim();
    return cachedSessionSecret;
  }
  const fresh = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(secretPath, fresh, { mode: 0o600 });
  cachedSessionSecret = fresh;
  return cachedSessionSecret;
}
